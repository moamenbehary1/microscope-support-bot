const fs = require('fs');
let html = fs.readFileSync('web/hr.html', 'utf8');

// 1. Remove Firebase SDKs
html = html.replace(/<script src="https:\/\/www\.gstatic\.com\/firebasejs\/10\.12\.0\/firebase-[a-z]+-compat\.js"><\/script>\n/g, '');

// 2. Replace initFirebase & FIREBASE_CONFIG with FB wrapper
const fbWrapper = `const FB = {
  url: '{{FB_URL}}',
  secret: '{{FB_SECRET}}',
  async get(path) {
    const res = await fetch(\`\${this.url}\${path}.json?auth=\${this.secret}\`);
    return res.json();
  },
  async set(path, data) {
    const res = await fetch(\`\${this.url}\${path}.json?auth=\${this.secret}\`, {
      method: 'PUT', headers:{'Content-Type':'application/json'}, body: JSON.stringify(data)
    });
    return res.json();
  },
  async update(path, data) {
    const res = await fetch(\`\${this.url}\${path}.json?auth=\${this.secret}\`, {
      method: 'PATCH', headers:{'Content-Type':'application/json'}, body: JSON.stringify(data)
    });
    return res.json();
  },
  async push(path, data) {
    const res = await fetch(\`\${this.url}\${path}.json?auth=\${this.secret}\`, {
      method: 'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify(data)
    });
    return res.json();
  },
  async del(path) {
    await fetch(\`\${this.url}\${path}.json?auth=\${this.secret}\`, { method: 'DELETE' });
  }
};

function initFirebase() {
  if (FB.url.startsWith('{{') || FB.secret.startsWith('{{')) {
    document.getElementById('auth-screen').classList.add('show');
    document.getElementById('auth-err').textContent = '⚙️ يرجى إعداد الـ Secret من الـ Backend أولاً.';
    return false;
  }
  return true;
}
`;
html = html.replace(/const FIREBASE_CONFIG = \{[\s\S]*?function showFirebaseSetup\(\) \{[\s\S]*?\}/, fbWrapper);
html = html.replace(/let firebaseApp, auth, db, functions;\n/g, '');

// 3. Replace HRAuth
const newAuth = `const HRAuth = {
  currentUser: null,
  async login() {
    const input = document.getElementById('code-input');
    const errEl = document.getElementById('auth-err');
    const btn   = document.getElementById('auth-btn');
    const code  = input.value.trim().toUpperCase();
    if (!code) { errEl.textContent = '⚠️ أدخل رمز الوصول.'; return; }
    btn.disabled = true;
    btn.textContent = 'جاري التحقق...';
    errEl.textContent = '';
    try {
      const users = await FB.get('/hr_users') || {};
      let user = null;
      for (const uid in users) {
        if (users[uid].codeHash === code || users[uid].code === code) {
          user = { uid, ...users[uid] };
          break;
        }
      }
      if (!user && Object.keys(users).length === 0) {
        const uid = 'usr_' + Date.now();
        user = { uid, name: 'Super Admin', role: 'superAdmin', active: true, code: code };
        await FB.set('/hr_users/' + uid, user);
      }
      if (!user) throw new Error('INVALID_CODE');
      if (user.active === false) throw new Error('DISABLED');
      this.currentUser = { uid: user.uid, role: user.role, name: user.name, headId: user.headId };
      localStorage.setItem('hr_session', JSON.stringify(this.currentUser));
      await this._onSignedIn();
    } catch(e) {
      console.error(e);
      errEl.textContent = '❌ رمز الوصول غير صحيح.';
    } finally {
      btn.disabled = false;
      btn.textContent = '🔑 دخول النظام';
    }
  },
  async _onSignedIn() {
    document.getElementById('auth-screen').classList.remove('show');
    document.getElementById('app').classList.add('show');
    App.initAfterAuth();
  },
  logout() {
    localStorage.removeItem('hr_session');
    location.reload();
  },
  get role() { return this.currentUser?.role || 'hr'; },
  get uid()  { return this.currentUser?.uid; },
  get name() { return this.currentUser?.name || 'مستخدم'; },
  isSuperAdmin() { return this.role === 'superAdmin'; },
  isHead()       { return this.role === 'head' || this.role === 'superAdmin'; },
  isHR()         { return ['hr','head','superAdmin'].includes(this.role); },
};`;
html = html.replace(/const HRAuth = \{[\s\S]*?isHR\(\)[\s\S]*?\};\n/, newAuth);

// 4. Replace FS and MockFunctions
const newFS = `const FS = {
  async get(collection, id) {
    const data = await FB.get(\`/hr_\${collection}/\${id}\`);
    return data ? { id, ...data } : null;
  },
  async list(collection, ...constraints) {
    const data = await FB.get(\`/hr_\${collection}\`) || {};
    let arr = Object.keys(data).map(k => ({ id: k, ...data[k] }));
    for (const c of constraints) {
      if (c[0] === 'where') {
        arr = arr.filter(item => {
          if (c[2] === '==') return item[c[1]] === c[3];
          if (c[2] === 'in') return c[3].includes(item[c[1]]);
          if (c[2] === 'array-contains') return Array.isArray(item[c[1]]) && item[c[1]].includes(c[3]);
          return true;
        });
      } else if (c[0] === 'orderBy') {
        arr.sort((a,b) => {
          const va = a[c[1]] || 0; const vb = b[c[1]] || 0;
          return c[2] === 'desc' ? (vb > va ? 1 : -1) : (va > vb ? 1 : -1);
        });
      } else if (c[0] === 'limit') {
        arr = arr.slice(0, c[1]);
      }
    }
    return arr;
  },
  async add(collection, data) {
    data.createdAt = new Date().toISOString();
    const res = await FB.push(\`/hr_\${collection}\`, data);
    return res.name;
  },
  async set(collection, id, data) {
    await FB.update(\`/hr_\${collection}/\${id}\`, data);
  },
  async update(collection, id, data) {
    data.updatedAt = new Date().toISOString();
    await FB.update(\`/hr_\${collection}/\${id}\`, data);
  },
  async del(collection, id) {
    await FB.del(\`/hr_\${collection}/\${id}\`);
  },
  ts() { return new Date().toISOString(); },
  now() { return new Date().toISOString(); },
};

const MockFunctions = {
  signInWithCode: async () => {},
  saveEvaluationDraft: async (data) => {
    data.status = 'draft';
    await FS.set('evaluations', data.id, data);
    return { id: data.id };
  },
  submitEvaluation: async (data) => {
    data.status = 'submitted';
    data.submittedAt = FS.now();
    await FS.update('evaluations', data.evalId, data);
    return { success: true };
  },
  requestEvalReopen: async (data) => {
    await FS.add('reopenRequests', {
      evalId: data.evalId, memberId: data.memberId, cycleId: data.cycleId,
      hrId: HRAuth.uid, hrName: HRAuth.name, reason: data.reason, status: 'pending', timestamp: FS.now()
    });
    return { success: true };
  },
  addMember: async (data) => {
    await FS.add('members', {
      telegramId: data.telegramId, name: data.name, university: data.university,
      team: data.team, subTeam: data.subTeam || null, status: data.status
    });
  },
  createHRUser: async (data) => {
    const code = Math.random().toString(36).substring(2, 8).toUpperCase();
    await FS.add('users', { name: data.name, role: data.role, headId: data.headId, code: code, active: true });
  },
  rotateAccessCode: async (data) => {
    const code = Math.random().toString(36).substring(2, 8).toUpperCase();
    await FS.update('users', data.uid, { code: code });
  },
  disableAccessCode: async (data) => {
    await FS.update('users', data.uid, { active: false });
  },
  assignMember: async (data) => {
    const ts = FS.now();
    await FS.add('assignments', { hrId: data.hrId, memberId: data.memberId, timestamp: ts });
    await FS.update('members', data.memberId, { assignedHrId: data.hrId });
  },
  bulkAssign: async (data) => {
    for (const memId of data.memberIds) {
      await MockFunctions.assignMember({ hrId: data.hrId, memberId: memId });
    }
  },
  activateCycle: async (data) => {
    const cycles = await FS.list('cycles', ['where', 'status', '==', 'Active']);
    for (const c of cycles) await FS.update('cycles', c.id, { status: 'Closed' });
    await FS.update('cycles', data.cycleId, { status: 'Active' });
  },
  reopenEvaluation: async (data) => {
    await FS.update('evaluations', data.evalId, { status: 'reopened' });
  },
  decideReopenRequest: async (data) => {
    await FS.update('reopenRequests', data.reqId, { status: data.approved ? 'approved' : 'rejected' });
    if (data.approved) {
      const req = await FS.get('reopenRequests', data.reqId);
      await FS.update('evaluations', req.evalId, { status: 'reopened' });
    }
  },
  getGoogleOAuthUrl: async () => { return { url: 'data:text/html,<html><body><script>window.opener.postMessage({type:\\'GOOGLE_OAUTH_CODE\\', code:\\'local_export\\'}, \\'*\\');</script></body></html>' }; },
  exportToSheets: async (data) => { 
    const evals = await FS.list('evaluations', ['where', 'cycleId', '==', data.cycleId]);
    let csv = "Member,HR,Final Score,Status\\n";
    evals.forEach(e => csv += \`\${e.memberName},\${e.hrName},\${e.finalScore||0},\${e.status}\\n\`);
    const blob = new Blob(['\\uFEFF' + csv], { type: 'text/csv;charset=utf-8;' });
    return { sheetUrl: URL.createObjectURL(blob) };
  }
};
const functions = {
  httpsCallable: (name) => async (data) => {
    return { data: await MockFunctions[name](data) };
  }
};`;
html = html.replace(/const FS = \{[\s\S]*?now\(\) \{ return new Date\(\)\.toISOString\(\); \},\n\};/, newFS);

// 5. Replace session loading in Boot
const newBoot = `document.addEventListener('DOMContentLoaded', async () => {
  const ok = initFirebase();
  if (!ok) return;
  const session = localStorage.getItem('hr_session');
  if (session) {
    HRAuth.currentUser = JSON.parse(session);
    document.getElementById('app').classList.add('show');
    App.initAfterAuth();
  } else {
    document.getElementById('auth-screen').classList.add('show');
    setTimeout(() => document.getElementById('code-input')?.focus(), 100);
  }
});`;
html = html.replace(/document\.addEventListener\('DOMContentLoaded'[\s\S]*?\}\);\n\}\);/, newBoot);

fs.writeFileSync('web/hr.html', html);
console.log('Successfully updated hr.html');
