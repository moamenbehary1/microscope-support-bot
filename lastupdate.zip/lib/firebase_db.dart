import 'dart:async';
import 'dart:convert';
import 'package:http/http.dart' as http;
import 'config.dart';


class FirebaseDb {
  static String get _baseUrl {
    String url = Config.firebaseDatabaseUrl;
    if (url.endsWith('/')) {
      url = url.substring(0, url.length - 1);
    }
    return url;
  }
  static String get _authParam => '?auth=${Config.firebaseSecret}';

  /// Percent-encodes each segment of a Firebase REST path so Arabic, emoji,
  /// and other non-ASCII characters are transmitted correctly.
  static String _encodePath(String path) {
    return path
        .split('/')
        .map((seg) => seg.isEmpty ? seg : Uri.encodeComponent(seg))
        .join('/');
  }

  static Future<dynamic> _get(String path) async {
    try {
      final encoded = _encodePath(path);
      final response = await http
          .get(Uri.parse('$_baseUrl$encoded.json$_authParam'))
          .timeout(const Duration(seconds: 10));
      if (response.statusCode == 200) {
        if (response.body == 'null') return null;
        return json.decode(response.body);
      }
      print('[Firebase] GET $path failed: ${response.statusCode}');
      return null;
    } catch (e) {
      print('[Firebase] GET $path error: $e');
      return null;
    }
  }

  static Future<bool> _put(String path, dynamic data) async {
    try {
      final encoded = _encodePath(path);
      final response = await http
          .put(
            Uri.parse('$_baseUrl$encoded.json$_authParam'),
            body: json.encode(data),
          )
          .timeout(const Duration(seconds: 10));
      if (response.statusCode != 200) {
        print('[Firebase] PUT $path failed: ${response.statusCode}');
      }
      return response.statusCode == 200;
    } catch (e) {
      print('[Firebase] PUT $path error: $e');
      return false;
    }
  }

  static Future<bool> _patch(String path, dynamic data) async {
    try {
      final encoded = _encodePath(path);
      final response = await http
          .patch(
            Uri.parse('$_baseUrl$encoded.json$_authParam'),
            body: json.encode(data),
          )
          .timeout(const Duration(seconds: 10));
      if (response.statusCode != 200) {
        print('[Firebase] PATCH $path failed: ${response.statusCode}');
      }
      return response.statusCode == 200;
    } catch (e) {
      print('[Firebase] PATCH $path error: $e');
      return false;
    }
  }

  static Future<bool> _delete(String path) async {
    try {
      final encoded = _encodePath(path);
      final response = await http
          .delete(Uri.parse('$_baseUrl$encoded.json$_authParam'))
          .timeout(const Duration(seconds: 10));
      if (response.statusCode != 200) {
        print('[Firebase] DELETE $path failed: ${response.statusCode}');
      }
      return response.statusCode == 200;
    } catch (e) {
      print('[Firebase] DELETE $path error: $e');
      return false;
    }
  }

  static Future<String?> _post(String path, dynamic data) async {
    try {
      final encoded = _encodePath(path);
      final response = await http
          .post(
            Uri.parse('$_baseUrl$encoded.json$_authParam'),
            body: json.encode(data),
          )
          .timeout(const Duration(seconds: 10));
      if (response.statusCode == 200) {
        final res = json.decode(response.body);
        return res['name']; // Returns the generated ID
      }
      print('[Firebase] POST $path failed: ${response.statusCode}');
      return null;
    } catch (e) {
      print('[Firebase] POST $path error: $e');
      return null;
    }
  }

  // --- Users & Admins ---

  static Future<void> registerUser(int userId) async {
    final existing = await _get('/users/$userId');
    if (existing == null) {
      await _put('/users/$userId', {
        'joinedAt': DateTime.now().toIso8601String(),
      });
    }
  }

  static Future<String> getUserLanguage(int userId) async {
    final data = await _get('/users/$userId');
    if (data != null && data is Map && data.containsKey('language')) {
      return data['language'] as String;
    }
    return '';
  }

  static Future<void> setUserLanguage(int userId, String lang) async {
    await _patch('/users/$userId', {'language': lang});
  }

  static Future<List<int>> getAdmins() async {
    final data = await _get('/admins');
    if (data == null) return [];
    return (data as Map<String, dynamic>).keys.map((e) => int.parse(e)).toList();
  }

  static Future<void> addAdmin(int userId) async {
    await _put('/admins/$userId', true);
  }

  static Future<void> removeAdmin(int userId) async {
    await _delete('/admins/$userId');
  }

  static Future<bool> isAdmin(int userId) async {
    if (userId == Config.superAdminId) return true;
    final admins = await getAdmins();
    return admins.contains(userId);
  }

  static Future<bool> isBanned(int userId) async {
    final data = await _get('/banned_users/$userId');
    return data != null && data == true;
  }

  static Future<void> banUser(int userId) async {
    await _put('/banned_users/$userId', true);
  }

  static Future<void> unbanUser(int userId) async {
    await _delete('/banned_users/$userId');
  }

  // --- Contributors ---

  static Future<void> setContributor(int userId, {String name = ''}) async {
    await _put('/contributors/$userId', {
      'approved': true,
      if (name.isNotEmpty) 'name': name,
    });
  }

  /// Returns all contributors as Map<userId, {track, subject, name?}>
  static Future<Map<String, dynamic>> getAllContributors() async {
    final data = await _get('/contributors');
    if (data == null) return {};
    return data as Map<String, dynamic>;
  }

  static Future<Map<String, dynamic>?> getContributor(int userId) async {
    return await _get('/contributors/$userId');
  }

  static Future<void> removeContributor(int userId) async {
    await deleteAllContributorMaterials(userId);
    await _delete('/contributors/$userId');
  }

  static Future<bool> isContributor(int userId) async {
    final data = await getContributor(userId);
    return data != null;
  }

  // --- Feedback ---

  static Future<void> addFeedback(int userId, String message) async {
    await _post('/feedbacks', {
      'userId': userId,
      'message': message,
      'timestamp': DateTime.now().toIso8601String(),
    });
  }

  static Future<void> addWebFeedback({
    required String name,
    required int rating,
    String category = 'عام',
    required String message,
  }) async {
    final ratingStars = rating > 0 ? '$rating/5 ' + ('⭐' * rating) : 'بدون تقييم';
    final formatted = '⭐ التقييم: $ratingStars\n$message';
    final entry = {
      'userId': name,
      'name': name,
      'rating': rating,
      'category': category,
      'message': formatted,
      'text': formatted,
      'source': 'team_web_page',
      'timestamp': DateTime.now().toIso8601String(),
    };
    await _post('/feedbacks', entry);
    await _post('/feedback', entry);
  }

  static Future<Map<String, dynamic>> getFeedbacks() async {
    final data = await _get('/feedbacks');
    if (data == null) return {};
    return data as Map<String, dynamic>;
  }

  // --- Curriculum (Content) ---

  // Get all tracks
  static Future<List<String>> getTracks() async {
    final data = await _get('/curriculum');
    if (data == null) return [];
    return (data as Map<String, dynamic>).keys.where((k) => k != '_placeholder').toList();
  }

  // Get subjects for a track
  static Future<List<String>> getSubjects(String track) async {
    final data = await _get('/curriculum/$track');
    if (data == null || data is! Map) return [];
    return data.keys.map((k) => k.toString()).where((k) => k != '_placeholder').toList();
  }

  // Add a track to curriculum
  static Future<void> addTrack(String track) async {
    final clean = track.trim();
    if (clean.isEmpty) return;
    await _put('/curriculum/$clean/_placeholder', true);
  }

  // Add a subject to a track
  static Future<void> addSubject(String track, String subject) async {
    final cleanT = track.trim();
    final cleanS = subject.trim();
    if (cleanT.isEmpty || cleanS.isEmpty) return;
    await _put('/curriculum/$cleanT/$cleanS/_placeholder', true);
  }

  // Delete a subject from a track
  static Future<void> deleteSubject(String track, String subject) async {
    final cleanT = track.trim();
    final cleanS = subject.trim();
    if (cleanT.isEmpty || cleanS.isEmpty) return;
    await _delete('/curriculum/$cleanT/$cleanS');
  }

  // Get material types for a subject
  static Future<List<String>> getMaterialTypes(String track, String subject) async {
    final data = await _get('/curriculum/$track/$subject');
    if (data == null || data is! Map) return [];
    return data.keys.map((k) => k.toString()).where((k) => k != '_placeholder').toList();
  }

  // Get materials for a type (filters out _placeholder and handles strings / maps safely)
  static Future<Map<String, dynamic>> getMaterials(String track, String subject, String type) async {
    final data = await _get('/curriculum/$track/$subject/$type');
    if (data == null) return {};
    if (data is Map) {
      final res = <String, dynamic>{};
      data.forEach((k, v) {
        final keyStr = k.toString();
        if (keyStr == '_placeholder') return;
        if (v is Map) {
          final m = Map<String, dynamic>.from(v);
          m['name'] = m['name'] ?? m['title'] ?? m['file_name'] ?? keyStr;
          res[keyStr] = m;
        } else if (v != null) {
          res[keyStr] = {'name': v.toString(), 'file_id': '', 'file_type': 'text'};
        }
      });
      return res;
    } else if (data is String) {
      return {'content': {'name': data, 'file_id': '', 'file_type': 'text'}};
    }
    return {};
  }

  // Add material
  static Future<String?> addMaterial(String track, String subject, String type, Map<String, dynamic> materialData) async {
    return await _post('/curriculum/$track/$subject/$type', materialData);
  }

  // --- Contributor Materials Index ---

  static Future<void> addContributorMaterialRef(int userId, String materialId, Map<String, dynamic> data) async {
    await _put('/contributor_materials/$userId/$materialId', data);
  }

  static Future<Map<String, dynamic>> getContributorMaterials(int userId) async {
    final data = await _get('/contributor_materials/$userId');
    if (data == null) return {};
    return data as Map<String, dynamic>;
  }

  static Future<void> removeContributorMaterialRef(int userId, String materialId) async {
    await _delete('/contributor_materials/$userId/$materialId');
  }

  static Future<void> deleteAllContributorMaterials(int userId) async {
    final materials = await getContributorMaterials(userId);
    for (var entry in materials.entries) {
      final matId = entry.key;
      final data = entry.value as Map<String, dynamic>;
      final track = data['track'] as String? ?? '';
      final subject = data['subject'] as String? ?? '';
      final type = data['type'] as String? ?? '';
      if (track.isNotEmpty && subject.isNotEmpty && type.isNotEmpty) {
        await deleteMaterial(track, subject, type, matId);
      }
    }
    await _delete('/contributor_materials/$userId');
  }

  // Delete material (deletes ONLY the specific material node)
  static Future<void> deleteMaterial(String track, String subject, String type, String materialId) async {
    final original = await getMaterial(track, subject, type, materialId);
    await _delete('/curriculum/$track/$subject/$type/$materialId');
    if (original != null && original['added_by'] != null) {
      final addedBy = int.tryParse(original['added_by'].toString());
      if (addedBy != null) {
        await removeContributorMaterialRef(addedBy, materialId);
      }
    }
  }

  // Update material (Replace)
  static Future<void> updateMaterial(String track, String subject, String type, String materialId, Map<String, dynamic> updateData) async {
    await _patch('/curriculum/$track/$subject/$type/$materialId', updateData);
  }
  
  static Future<Map<String, dynamic>?> getMaterial(String track, String subject, String type, String materialId) async {
     final data = await _get('/curriculum/$track/$subject/$type/$materialId');
     if (data == null) return null;
     if (data is Map) {
       final m = Map<String, dynamic>.from(data);
       m['name'] = m['name'] ?? m['title'] ?? m['file_name'] ?? materialId;
       return m;
     } else if (data != null) {
       return {'name': data.toString(), 'file_id': '', 'file_type': 'text'};
     }
     return null;
  }

  // Search curriculum across all tracks, subjects, and materials
  static Future<List<Map<String, dynamic>>> searchCurriculum(String query) async {
    final q = query.trim().toLowerCase();
    if (q.isEmpty) return [];
    final data = await _get('/curriculum');
    if (data == null || data is! Map) return [];
    
    final results = <Map<String, dynamic>>[];
    data.forEach((tKey, subjects) {
      if (tKey == '_placeholder' || subjects is! Map) return;
      final track = tKey.toString();
      subjects.forEach((sKey, types) {
        if (sKey == '_placeholder' || types is! Map) return;
        final subject = sKey.toString();
        
        if (subject.toLowerCase().contains(q)) {
          results.add({
            'kind': 'subject',
            'track': track,
            'subject': subject,
            'title': '📋 $subject ($track)',
          });
        }

        types.forEach((tyKey, mats) {
          if (tyKey == '_placeholder' || mats is! Map) return;
          final type = tyKey.toString();
          mats.forEach((mKey, mVal) {
            if (mKey == '_placeholder') return;
            String mName = mKey.toString();
            String fType = 'document';
            if (mVal is Map) {
              mName = mVal['name']?.toString() ?? mName;
              fType = mVal['file_type']?.toString() ?? fType;
            } else if (mVal is String) {
              mName = mVal;
            }
            if (mName.toLowerCase().contains(q) || type.toLowerCase().contains(q)) {
              results.add({
                'kind': 'material',
                'track': track,
                'subject': subject,
                'matType': type,
                'materialId': mKey.toString(),
                'title': '📄 $mName ($subject)',
                'file_type': fType,
              });
            }
          });
        });
      });
    });
    return results.take(15).toList();
  }

  // Get latest updates for a list of registered subjects in tables
  static Future<List<Map<String, dynamic>>> getLatestScheduleUpdates(List<String> userSubjects, [int limit = 6]) async {
    final data = await _get('/curriculum');
    if (data == null || data is! Map) return [];
    
    final updates = <Map<String, dynamic>>[];
    data.forEach((tKey, subjects) {
      if (tKey == '_placeholder' || subjects is! Map) return;
      final track = tKey.toString();
      subjects.forEach((sKey, types) {
        if (sKey == '_placeholder' || types is! Map) return;
        final subject = sKey.toString();
        
        if (!userSubjects.contains(subject)) return;

        types.forEach((tyKey, mats) {
          if (tyKey == '_placeholder' || mats is! Map) return;
          final type = tyKey.toString();
          mats.forEach((mKey, mVal) {
            if (mKey == '_placeholder') return;
            String mName = mKey.toString();
            String fType = 'document';
            if (mVal is Map) {
              mName = mVal['name']?.toString() ?? mName;
              fType = mVal['file_type']?.toString() ?? fType;
            } else if (mVal is String) {
              mName = mVal;
            }
            updates.add({
              'track': track,
              'subject': subject,
              'type': type,
              'matId': mKey.toString(),
              'name': mName,
              'file_type': fType,
            });
          });
        });
      });
    });
    return updates.reversed.take(limit).toList();
  }

  static Future<void> deleteFeedback(String feedbackId) async {
    await _delete('/feedbacks/$feedbackId');
    await _delete('/feedback/$feedbackId');
  }

  // --- Analytics ---

  static Future<void> logMaterialAccess(String materialId, String materialName) async {
    final data = await _get('/analytics/top_accessed/$materialId');
    int count = 1;
    if (data != null && data['count'] != null) {
      count = data['count'] + 1;
    }
    await _put('/analytics/top_accessed/$materialId', {
      'count': count,
      'name': materialName,
    });
  }
  
  static Future<Map<String, dynamic>> getStats() async {
    final users = await _get('/users') as Map<String, dynamic>? ?? {};
    final analytics = await _get('/analytics/top_accessed') as Map<String, dynamic>? ?? {};
    return {
      'totalUsers': users.length,
      'topMaterials': analytics
    };
  }
  
  static Future<List<int>> getAllUsers() async {
    final users = await _get('/users') as Map<String, dynamic>? ?? {};
    return users.keys.map((e) => int.tryParse(e) ?? 0).where((e) => e != 0).toList();
  }

  static Future<void> wipeCurriculum() async {
    await _delete('/curriculum');
    await _delete('/analytics');
  }

  // --- Super Admin Ownership ---
  static Future<int> getSuperAdmin() async {
    final data = await _get('/super_admin');
    if (data != null && data is Map && data.containsKey('id')) {
      return data['id'] as int;
    }
    // Fallback to .env
    return Config.superAdminId;
  }

  static Future<void> setSuperAdmin(int newAdminId) async {
    await _put('/super_admin', {'id': newAdminId});
    // Ensure the new owner is also a regular admin
    await addAdmin(newAdminId);
  }

  // --- Bot Features Visibility Config ---
  static const Map<String, bool> defaultFeatures = {
    'departments': true,
    'tables': true,
    'miko': true,
    'smart_search': true,
    'student_tools': true,
    'contribute': true,
    'contact_admin': true,
  };

  static const Map<String, String> featureDisplayNames = {
    'departments': '📚 تصفح الأقسام والمواد',
    'tables': '📅 الجداول الدراسية التفاعلية',
    'miko': '🤖 مساعد ميكو الذكي (Miko AI)',
    'smart_search': '🔍 البحث الذكي في المحاضرات (Beta)',
    'student_tools': '🧰 أدوات الطالب والمذاكرة (GPA/مؤقت/مفضلة)',
    'contribute': '🤝 زر طلب الانضمام كمساهم',
    'contact_admin': '💬 زر التواصل مع الإدارة',
  };

  static Future<Map<String, bool>> getFeaturesConfig() async {
    final data = await _get('/features_config');
    final res = Map<String, bool>.from(defaultFeatures);
    if (data != null && data is Map) {
      data.forEach((k, v) {
        if (v is bool) res[k.toString()] = v;
      });
    }
    return res;
  }

  static Future<void> toggleFeature(String key, bool enabled) async {
    await _put('/features_config/$key', enabled);
  }

  // --- Contributor Requests ---
  static Future<void> addRequest(int userId, {String name = ''}) async {
    await _put('/requests/$userId', {
      'timestamp': DateTime.now().toIso8601String(),
      if (name.isNotEmpty) 'name': name,
    });
  }

  static Future<void> updateRequestMessageIds(int userId, Map<String, dynamic> messageIds) async {
    await _patch('/requests/$userId', {
      'messageIds': messageIds,
    });
  }

  static Future<Map<String, dynamic>?> getRequest(int userId) async {
    return await _get('/requests/$userId');
  }

  static Future<Map<String, dynamic>> getPendingRequests() async {
    final data = await _get('/requests');
    if (data == null) return {};
    return data as Map<String, dynamic>;
  }

  static Future<void> removeRequest(int userId) async {
    await _delete('/requests/$userId');
  }

  static Future<void> wipeUsers() async {
    await _delete('/users');
  }

  // ── Tables & Schedule ────────────────────────────────────────────────
  
  static Future<void> saveTable(int userId, String tableName, String track, List<String> subjectsWithTracks) async {
    // Extract pure subject names for subscriptions, while saving subjectsWithTracks to DB
    final List<String> subjects = subjectsWithTracks.map((s) => s.contains('|') ? s.split('|')[1] : s).toList();
    
    await _put('/users/$userId/tables/$tableName', {
      'track': track,
      'subjects': subjects,
      'subjects_with_tracks': subjectsWithTracks,
    });
    // Update subscriptions
    for (var subject in subjects) {
      await _put('/subject_subscribers/$subject/$userId', true);
    }
  }

  static Future<Map<String, dynamic>> getTables(int userId) async {
    final data = await _get('/users/$userId/tables');
    if (data == null) return {};
    return data as Map<String, dynamic>;
  }

  static Future<void> deleteTable(int userId, String tableName) async {
    final tables = await getTables(userId);
    if (tables.containsKey(tableName)) {
      final subjects = (tables[tableName]['subjects'] as List<dynamic>?)?.cast<String>() ?? [];
      await _delete('/users/$userId/tables/$tableName');
      await _recalculateUserSubscriptions(userId, subjects);
    }
  }

  static Future<void> deleteAllTables(int userId) async {
    final tables = await getTables(userId);
    List<String> allSubjects = [];
    tables.forEach((key, val) {
      final subs = (val['subjects'] as List<dynamic>?)?.cast<String>() ?? [];
      allSubjects.addAll(subs);
    });
    await _delete('/users/$userId/tables');
    for (var subject in allSubjects) {
      await _delete('/subject_subscribers/$subject/$userId');
    }
  }

  static Future<void> _recalculateUserSubscriptions(int userId, List<String> subjectsToCheck) async {
    // If a table is deleted, check if the subjects exist in other tables. If not, unsubscribe.
    final tables = await getTables(userId);
    Set<String> remainingSubjects = {};
    tables.forEach((key, val) {
      final subs = (val['subjects'] as List<dynamic>?)?.cast<String>() ?? [];
      remainingSubjects.addAll(subs);
    });

    for (var subject in subjectsToCheck) {
      if (!remainingSubjects.contains(subject)) {
        await _delete('/subject_subscribers/$subject/$userId');
      }
    }
  }

  static Future<List<int>> getSubjectSubscribers(String subject) async {
    final data = await _get('/subject_subscribers/$subject');
    if (data == null) return [];
    final map = data as Map<String, dynamic>;
    return map.keys.map((e) => int.tryParse(e) ?? 0).where((e) => e != 0).toList();
  }

  static Future<bool> saveMember(String id, Map<String, dynamic> data) async {
    return await _put('/members/$id', data);
  }

  // --- Favorites (Bookmarks) [BETA] ---
  static Future<void> addFavorite(int userId, String track, String subject, String type, String matId, String title) async {
    final rawKey = '$track|$subject|$matId';
    final favKey = 'fav_${rawKey.hashCode.abs()}';
    await _put('/users/$userId/favorites/$favKey', {
      'track': track,
      'subject': subject,
      'type': type,
      'mat_id': matId,
      'title': title,
      'saved_at': DateTime.now().toIso8601String(),
    });
  }

  static Future<Map<String, dynamic>> getFavorites(int userId) async {
    final data = await _get('/users/$userId/favorites');
    if (data == null || data is! Map) return {};
    return Map<String, dynamic>.from(data);
  }

  static Future<void> removeFavorite(int userId, String favKey) async {
    await _delete('/users/$userId/favorites/$favKey');
  }

  // --- Users by Track ---
  static Future<List<int>> getUsersForTrack(String track) async {
    final data = await _get('/users');
    if (data == null || data is! Map) return [];
    final List<int> usersInTrack = [];
    data.forEach((uidStr, val) {
      if (val is Map && val.containsKey('tables')) {
        final tables = val['tables'];
        if (tables is Map) {
          for (var t in tables.values) {
            if (t is Map && t['track'] == track) {
              final id = int.tryParse(uidStr.toString());
              if (id != null) usersInTrack.add(id);
              break;
            }
          }
        }
      }
    });
    return usersInTrack;
  }

  // ─── Microscope Missions ───
  static Future<Map<String, dynamic>> getMissions({String? status, String? category}) async {
    final data = await _get('/missions');
    if (data == null || data is! Map) return {};
    final map = Map<String, dynamic>.from(data);
    if (status != null && status.isNotEmpty && status != 'all') {
      map.removeWhere((_, v) => v is! Map || v['status'] != status);
    }
    if (category != null && category.isNotEmpty && category != 'all') {
      map.removeWhere((_, v) => v is! Map || v['category'] != category);
    }
    return map;
  }

  static Future<Map<String, dynamic>?> getMission(String id) async {
    final data = await _get('/missions/$id');
    if (data == null || data is! Map) return null;
    return Map<String, dynamic>.from(data);
  }

  static Future<void> saveMission(String id, Map<String, dynamic> mission) async {
    await _put('/missions/$id', mission);
  }

  static Future<void> updateMissionStatus(String id, String status) async {
    await _patch('/missions/$id', {
      'status': status,
      'updated_at': DateTime.now().toIso8601String(),
    });
  }

  static Future<void> deleteMission(String id) async {
    await _delete('/missions/$id');
  }

  static Future<void> seedOfficialMissions() async {
    final defaultTasks = [
      {
        'id': 'tsk_p1_interviews',
        'category': 'timeline',
        'title': 'المرحلة الأولى: التقديمات والمقابلات (Interviews)',
        'due_date': '2026-10-21',
        'description': 'إعلان فتح باب التقديم ومتابعة الاستمارات، فرز المتقدمين وتحديد مواعيد المقابلات واختيار المقبولين.',
        'committees': 'HR, PR, Social Media',
        'head_name': 'مسؤول الموارد البشرية (HR Head)',
        'priority': 'high',
        'status': 'progress',
        'created_at': DateTime.now().toIso8601String(),
      },
      {
        'id': 'tsk_p2_onboarding',
        'category': 'timeline',
        'title': 'المرحلة الثانية: التسكين والترحيب بالأعضاء الجدد',
        'due_date': '2026-10-24',
        'description': 'إضافة الأعضاء المقبولين إلى لجانهم الرسمية بعد فرز المقابلات وإرسال رسائل الترحيب الرسمية وتوجيههم.',
        'committees': 'HR, PR, PM',
        'head_name': 'إدارة العمليات والـ HR',
        'priority': 'high',
        'status': 'received',
        'created_at': DateTime.now().toIso8601String(),
      },
      {
        'id': 'tsk_p3_curriculum_audit',
        'category': 'execution',
        'title': 'المرحلة الثالثة: تدقيق المناهج وحصر النواقص العلمية',
        'due_date': '2026-11-05',
        'description': 'مراجعة المناهج والأقسام، والتأكد من رفع جميع المحاضرات والملخصات لجميع الفرق الدراسية وسد أي ثغرات.',
        'committees': 'Academic, Data, IT',
        'head_name': 'مسؤول اللجنة الأكاديمية والبيانات',
        'priority': 'high',
        'status': 'progress',
        'created_at': DateTime.now().toIso8601String(),
      },
      {
        'id': 'tsk_p4_bot_v2_launch',
        'category': 'execution',
        'title': 'المرحلة الرابعة: إطلاق النسخة المطورة من بوت وتطبيقات ميكروسكوب',
        'due_date': '2026-11-15',
        'description': 'تدشين الميزات الذكية (البحث الذكي، أدوات الطالب، إدارة المهام، ونظام الإشعارات التلقائية).',
        'committees': 'IT, PM, PR',
        'head_name': 'فريق التطوير والـ IT Lead',
        'priority': 'high',
        'status': 'progress',
        'created_at': DateTime.now().toIso8601String(),
      },
      {
        'id': 'tsk_p5_midterm_support',
        'category': 'term2',
        'title': 'المرحلة الخامسة: حملة دعم امتحانات الميدتيرم وبنوك الأسئلة',
        'due_date': '2026-11-28',
        'description': 'توفير بنوك أسئلة تفاعلية ومراجعات ليلة الامتحان للطلاب مع دعم فني مستمر وإرشاد دراسي مكثف.',
        'committees': 'Academic, Social Media, PR',
        'head_name': 'لجنة المحتوى الأكاديمي',
        'priority': 'normal',
        'status': 'received',
        'created_at': DateTime.now().toIso8601String(),
      },
      {
        'id': 'tsk_p6_institutional_dev',
        'category': 'improvement',
        'title': 'المرحلة السادسة: أتمتة التقارير الشهرية والتطوير المؤسسي',
        'due_date': '2026-12-10',
        'description': 'بناء لوحات مؤشرات الأداء KPIs ومتابعة معدل إنجاز اللجان وملاحظات الطلاب واستبيانات الجودة.',
        'committees': 'HR, PM, IT',
        'head_name': 'الإدارة العليا للعمليات',
        'priority': 'normal',
        'status': 'received',
        'created_at': DateTime.now().toIso8601String(),
      }
    ];

    for (var t in defaultTasks) {
      await saveMission(t['id'] as String, t);
    }
  }


  // ── Auth Code for Contributor Actions ─────────────────────────────────────
  static Future<void> setAuthCodeWithLimits({
    required String code,
    required int maxUses,
    required Duration validity,
    required int createdBy,
  }) async {
    final now = DateTime.now();
    final expiresAt = now.add(validity);
    await _put('/auth_code', {
      'code': code.trim(),
      'max_uses': maxUses,
      'remaining_uses': maxUses,
      'created_at': now.toIso8601String(),
      'expires_at': expiresAt.toIso8601String(),
      'validity_minutes': validity.inMinutes,
      'created_by': createdBy,
      'is_active': true,
    });
  }

  static Future<void> setAuthCode(String code) async {
    // Default: 1 use, 30 minutes
    await setAuthCodeWithLimits(
      code: code,
      maxUses: 1,
      validity: const Duration(minutes: 30),
      createdBy: 0,
    );
  }

  static Future<Map<String, dynamic>?> getAuthCodeDetails() async {
    final data = await _get('/auth_code');
    if (data == null || data is! Map) return null;
    return Map<String, dynamic>.from(data);
  }

  static Future<String?> getAuthCode() async {
    final details = await getAuthCodeDetails();
    if (details == null || details['is_active'] != true) return null;
    return details['code']?.toString();
  }

  /// Verifies input code against the active auth code.
  /// Returns:
  /// - 'valid': Code matched and 1 use was consumed
  /// - 'expired_time': Code duration expired
  /// - 'expired_uses': Code consumed all its allowed uses
  /// - 'invalid': Code string does not match
  /// - 'not_found': No active code exists
  static Future<String> verifyAndConsumeAuthCode(String inputCode) async {
    final details = await getAuthCodeDetails();
    if (details == null) return 'not_found';

    final isActive = details['is_active'] == true;
    if (!isActive) return 'not_found';

    final storedCode = details['code']?.toString().trim();
    if (storedCode == null || storedCode != inputCode.trim()) {
      return 'invalid';
    }

    // Check expiration by time
    final expiresAtStr = details['expires_at']?.toString();
    if (expiresAtStr != null) {
      final expiresAt = DateTime.tryParse(expiresAtStr);
      if (expiresAt != null && DateTime.now().isAfter(expiresAt)) {
        await _patch('/auth_code', {'is_active': false});
        return 'expired_time';
      }
    }

    // Check remaining uses
    final remainingUses = details['remaining_uses'] as int? ?? 1;
    if (remainingUses <= 0) {
      await _patch('/auth_code', {'is_active': false});
      return 'expired_uses';
    }

    // Consume 1 use
    final newRemaining = remainingUses - 1;
    await _patch('/auth_code', {
      'remaining_uses': newRemaining,
      'is_active': newRemaining > 0,
      'last_used_at': DateTime.now().toIso8601String(),
    });

    return 'valid';
  }

  static Future<bool> verifyAuthCode(String inputCode) async {
    final status = await verifyAndConsumeAuthCode(inputCode);
    return status == 'valid';
  }

  static Future<void> revokeAuthCode() async {
    await _patch('/auth_code', {
      'is_active': false,
      'remaining_uses': 0,
      'revoked_at': DateTime.now().toIso8601String(),
    });
  }

  // ── Rename Material ────────────────────────────────────────────────────
  static Future<void> renameMaterial(
      String track, String subject, String type, String materialId, String newName) async {
    final original = await getMaterial(track, subject, type, materialId);
    await _patch('/curriculum/$track/$subject/$type/$materialId', {'name': newName});
    if (original != null && original['added_by'] != null) {
      final addedBy = int.tryParse(original['added_by'].toString());
      if (addedBy != null) {
        await _patch('/contributor_materials/$addedBy/$materialId', {'name': newName});
      }
    }
  }

  // ── Move Material ─────────────────────────────────────────────────────
  /// Moves a material from old path to new path. Returns the new material ID or null on failure.
  static Future<String?> moveMaterial({
    required String oldTrack,
    required String oldSubject,
    required String oldType,
    required String materialId,
    required String newTrack,
    required String newSubject,
    required String newType,
    String? newName,
  }) async {
    // 1. Fetch original data
    final original = await getMaterial(oldTrack, oldSubject, oldType, materialId);
    if (original == null) return null;

    // 2. Build new data
    final Map<String, dynamic> newData = Map<String, dynamic>.from(original);
    if (newName != null && newName.isNotEmpty) {
      newData['name'] = newName;
    }
    newData.remove('_placeholder');

    // 3. Write to new location
    final newId = await _post('/curriculum/$newTrack/$newSubject/$newType', newData);
    if (newId == null) return null;

    // 4. Delete from old location
    await deleteMaterial(oldTrack, oldSubject, oldType, materialId);

    // 5. Sync contributor material index
    final addedBy = int.tryParse(original['added_by']?.toString() ?? '');
    if (addedBy != null) {
      await removeContributorMaterialRef(addedBy, materialId);
      await addContributorMaterialRef(addedBy, newId, {
        'track': newTrack,
        'subject': newSubject,
        'type': newType,
        'name': newData['name'] ?? original['name'],
        'file_id': newData['file_id'] ?? original['file_id'],
        'file_type': newData['file_type'] ?? original['file_type'],
      });
    }

    return newId;
  }
}
