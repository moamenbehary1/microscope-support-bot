

/* ═══════════════════════════════════════════════
   Firebase Config — reads from injected server vars or localStorage
═══════════════════════════════════════════════ */
const FIREBASE_CONFIG = {
  // These should be set to your actual Firebase project config.
  // They are PUBLIC client config, NOT secrets. Safe in frontend.
  apiKey:            "{{FB_API_KEY}}",
  authDomain:        "{{FB_AUTH_DOMAIN}}",
  projectId:         "{{FB_PROJECT_ID}}",
  storageBucket:     "{{FB_STORAGE_BUCKET}}",
  messagingSenderId: "{{FB_MESSAGING_SENDER_ID}}",
  appId:             "{{FB_APP_ID}}"
};

// Fallback: read from localStorage (set by admin panel setup)
function getFirebaseConfig() {
  const injected = Object.entries(FIREBASE_CONFIG).every(([k,v]) => !v.startsWith('{{'));
  if (injected) return FIREBASE_CONFIG;
  // try localStorage fallback
  const stored = {};
  const keys = ['apiKey','authDomain','projectId','storageBucket','messagingSenderId','appId'];
  keys.forEach(k => { const v = localStorage.getItem('hr_fb_' + k); if(v) stored[k] = v; });
  if (stored.apiKey) return stored;
  return FIREBASE_CONFIG; // will fail, user sees config prompt
}

let firebaseApp, auth, db, functions;

function initFirebase() {
  const cfg = getFirebaseConfig();
  if (!cfg.apiKey || cfg.apiKey.startsWith('{{')) {
    showFirebaseSetup();
    return false;
  }
  try {
    firebaseApp = firebase.initializeApp(cfg);
    auth = firebase.auth();
    db = firebase.firestore();
    functions = firebase.functions();
    // Use emulators in dev if needed:
    // functions.useEmulator('localhost', 5001);
    return true;
  } catch(e) {
    console.error('Firebase init error:', e);
    return false;
  }
}

function showFirebaseSetup() {
  document.getElementById('auth-screen').classList.add('show');
  document.getElementById('auth-err').textContent = '⚙️ يرجى إعداد Firebase أولاً. تواصل مع الأدمن لإعداد النظام.';
}

/* ═══════════════════════════════════════════════
   Toast & Modal
═══════════════════════════════════════════════ */
const Toast = {
  show(msg, type='info', ms=4000) {
    const el = document.createElement('div');
    const types = {success:'ok', error:'err', warning:'warn', info:'info'};
    const icons = {success:'✅', error:'❌', warning:'⚠️', info:'ℹ️'};
    el.className = `toast ${types[type]||'info'}`;
    el.innerHTML = `<span>${icons[type]||'•'}</span><span>${msg}</span>`;
    document.getElementById('toasts').appendChild(el);
    setTimeout(() => el.remove(), ms);
  }
};

const Modal = {
  _res: null,
  open(title, html, okLabel='تأكيد', danger=false, wide=false) {
    document.getElementById('m-title').textContent = title;
    document.getElementById('m-body').innerHTML = html;
    const ok = document.getElementById('m-ok');
    ok.textContent = okLabel;
    ok.className = danger ? 'btn btn-danger' : 'btn btn-primary';
    const box = document.getElementById('modal-box');
    box.className = wide ? 'mbox wide' : 'mbox';
    box.style.position = 'relative';
    document.getElementById('overlay').classList.add('show');
    return new Promise(r => { this._res = r; });
  },
  close(val = false) {
    document.getElementById('overlay').classList.remove('show');
    if (this._res) { this._res(val); this._res = null; }
  },
  prompt(title, placeholder, okLabel='حفظ') {
    const id = 'pi' + Date.now();
    return this.open(title,
      `<div class="form-group"><input id="${id}" placeholder="${placeholder}" autocomplete="off" style="margin-top:4px"/></div>`,
      okLabel
    ).then(ok => {
      if (!ok) return null;
      return document.getElementById(id)?.value?.trim() || null;
    });
  }
};

document.getElementById('m-ok').onclick = () => Modal.close(true);
document.getElementById('overlay').addEventListener('click', e => {
  if (e.target === document.getElementById('overlay')) Modal.close();
});

/* ═══════════════════════════════════════════════
   HR Auth — Access Code via Cloud Function
═══════════════════════════════════════════════ */
const HRAuth = {
  currentUser: null,   // { uid, role, name, headId? }
  _superAdminIds: [],  // Telegram Admin IDs that map to superAdmin in HR

  async login() {
    const input = document.getElementById('code-input');
    const errEl = document.getElementById('auth-err');
    const btn   = document.getElementById('auth-btn');
    const code  = input.value.trim();

    if (!code) { errEl.textContent = '⚠️ أدخل رمز الوصول.'; return; }

    btn.disabled = true;
    btn.textContent = 'جاري التحقق...';
    errEl.textContent = '';

    try {
      // Call Cloud Function to verify code and get custom token
      const signIn = functions.httpsCallable('signInWithCode');
      const result = await signIn({ code });
      const { customToken, uid, role, name, headId } = result.data;

      // Sign in with custom token
      await auth.signInWithCustomToken(customToken);

      this.currentUser = { uid, role, name, headId };
      await this._onSignedIn();
    } catch(e) {
      console.error('Login error:', e);
      const msg = e.message || '';
      if (msg.includes('invalid') || msg.includes('wrong') || msg.includes('INVALID_CODE')) {
        errEl.textContent = '❌ رمز الوصول غير صحيح.';
      } else if (msg.includes('locked') || msg.includes('LOCKED')) {
        errEl.textContent = '🔒 تم قفل حسابك مؤقتًا، حاول لاحقًا.';
      } else if (msg.includes('disabled') || msg.includes('DISABLED')) {
        errEl.textContent = '❌ هذا الحساب معطّل، تواصل مع الأدمن.';
      } else {
        errEl.textContent = '❌ خطأ: ' + msg;
      }
    } finally {
      btn.disabled = false;
      btn.textContent = '🔑 دخول النظام';
    }
  },

  async _onSignedIn() {
    document.getElementById('auth-screen').classList.remove('show');
    document.getElementById('app').classList.add('show');

    // Load user profile from Firestore
    if (!this.currentUser) {
      const user = auth.currentUser;
      if (!user) { this.logout(); return; }
      const snap = await db.collection('users').doc(user.uid).get();
      if (snap.exists) {
        const d = snap.data();
        this.currentUser = { uid: user.uid, role: d.role, name: d.name, headId: d.headId };
      }
    }

    App.initAfterAuth();
  },

  logout() {
    auth.signOut().then(() => location.reload());
  },

  get role() { return this.currentUser?.role || 'hr'; },
  get uid()  { return this.currentUser?.uid || auth.currentUser?.uid; },
  get name() { return this.currentUser?.name || 'مستخدم'; },
  isSuperAdmin() { return this.role === 'superAdmin'; },
  isHead()       { return this.role === 'head' || this.role === 'superAdmin'; },
  isHR()         { return ['hr','head','superAdmin'].includes(this.role); },
};

/* ═══════════════════════════════════════════════
   App Controller
═══════════════════════════════════════════════ */
const App = {
  cur: null,

  initAfterAuth() {
    const role = HRAuth.role;

    // Show/hide nav based on role
    const isAdmin = HRAuth.isHead();
    const isSuperAdmin = HRAuth.isSuperAdmin();

    document.querySelectorAll('.hr-only').forEach(el => el.style.display = '');
    document.querySelectorAll('.admin-only').forEach(el => el.style.display = isAdmin ? '' : 'none');
    document.querySelectorAll('.superadmin-only').forEach(el => el.style.display = isSuperAdmin ? '' : 'none');

    // Role badge
    const roleBadge = document.getElementById('role-badge-display');
    const roleMap = { superAdmin: ['🔑 Super Admin', 'role-super'], head: ['👑 Head HR', 'role-head'], hr: ['🧑‍💼 HR Member', 'role-hr'] };
    const [rlbl, rcls] = roleMap[role] || ['👤 مستخدم', 'role-hr'];
    roleBadge.textContent = rlbl;
    roleBadge.className = 'role-badge ' + rcls;

    // User name
    document.getElementById('user-name-display').textContent = HRAuth.name;
    document.getElementById('header-role').textContent = rlbl;

    // Wire nav
    document.querySelectorAll('.nav-item[data-s]').forEach(el => {
      el.addEventListener('click', () => this.setSection(el.dataset.s));
    });

    // Default section
    const defaultSection = isAdmin ? 'admin-dashboard' : 'hr-dashboard';
    this.setSection(defaultSection);
  },

  setSection(s) {
    this.cur = s;
    document.querySelectorAll('.nav-item').forEach(e => e.classList.remove('active'));
    document.querySelector(`.nav-item[data-s="${s}"]`)?.classList.add('active');
    document.querySelectorAll('.page').forEach(p => p.classList.remove('active'));
    document.getElementById(`pg-${s}`)?.classList.add('active');

    const titles = {
      'hr-dashboard': 'لوحة تحكم الـ HR',
      'hr-evaluate': 'تقييم الأعضاء',
      'hr-history': 'سجل التقييمات',
      'admin-dashboard': 'لوحة الإدارة',
      'members-mgmt': 'إدارة الأعضاء',
      'hr-mgmt': 'إدارة الـ HR',
      'assignments': 'التعيينات',
      'cycles': 'دورات التقييم',
      'evaluations-list': 'التقييمات',
      'reopen-requests': 'طلبات إعادة الفتح',
      'criteria': 'معايير التقييم',
      'bonus-rules': 'قواعد المكافآت',
      'penalty-rules': 'قواعد الخصومات',
      'perf-levels': 'مستويات الأداء',
      'analytics': 'الإحصائيات والتحليل',
      'reports': 'التقارير',
      'export': 'التصدير',
      'audit-log': 'سجل النشاط',
    };
    document.getElementById('page-title').textContent = titles[s] || s;
    this.load(s);
  },

  async load(s) {
    try {
      const pg = document.getElementById(`pg-${s}`);
      if (!pg) return;
      await Pages[s]?.load(pg);
    } catch(e) {
      console.error('Page load error:', s, e);
      const pg = document.getElementById(`pg-${s}`);
      if (pg) pg.innerHTML = `<div class="empty"><span class="ico">⚠️</span><p>فشل تحميل الصفحة.<br><small style="color:var(--muted)">${e.message}</small></p></div>`;
    }
  }
};

/* ═══════════════════════════════════════════════
   Firestore Helpers
═══════════════════════════════════════════════ */
const FS = {
  async get(collection, id) {
    const snap = await db.collection(collection).doc(id).get();
    return snap.exists ? { id: snap.id, ...snap.data() } : null;
  },
  async list(collection, ...constraints) {
    let q = db.collection(collection);
    constraints.forEach(c => { q = q[c[0]](...c.slice(1)); });
    const snap = await q.get();
    return snap.docs.map(d => ({ id: d.id, ...d.data() }));
  },
  async add(collection, data) {
    const ref = await db.collection(collection).add({ ...data, createdAt: firebase.firestore.FieldValue.serverTimestamp() });
    return ref.id;
  },
  async set(collection, id, data) {
    await db.collection(collection).doc(id).set(data, { merge: true });
  },
  async update(collection, id, data) {
    await db.collection(collection).doc(id).update({ ...data, updatedAt: firebase.firestore.FieldValue.serverTimestamp() });
  },
  async del(collection, id) {
    await db.collection(collection).doc(id).delete();
  },
  ts() { return firebase.firestore.FieldValue.serverTimestamp(); },
  now() { return new Date().toISOString(); },
};

/* ═══════════════════════════════════════════════
   Utilities
═══════════════════════════════════════════════ */
function fmtDate(ts) {
  if (!ts) return '—';
  const d = ts.toDate ? ts.toDate() : new Date(ts);
  return d.toLocaleDateString('ar-EG', { year: 'numeric', month: 'short', day: 'numeric' });
}
function fmtDatetime(ts) {
  if (!ts) return '—';
  const d = ts.toDate ? ts.toDate() : new Date(ts);
  return d.toLocaleString('ar-EG', { year: 'numeric', month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit', hour12: true });
}
function deadlineCountdown(deadline) {
  if (!deadline) return '—';
  const d = deadline.toDate ? deadline.toDate() : new Date(deadline);
  const diff = d - new Date();
  if (diff <= 0) return '<span style="color:var(--danger)">انتهى الميعاد</span>';
  const days = Math.floor(diff / 86400000);
  const hours = Math.floor((diff % 86400000) / 3600000);
  const mins = Math.floor((diff % 3600000) / 60000);
  if (days > 0) return `${days}ي ${hours}س`;
  if (hours > 0) return `${hours}س ${mins}د`;
  return `${mins}د`;
}
function encStr(s) { return String(s || '').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;').replace(/'/g,'&#039;'); }
function statusBadge(status) {
  const map = {
    'Draft': ['مسودة', 'badge-muted'],
    'Active': ['نشطة', 'badge-success'],
    'Closed': ['مغلقة', 'badge-danger'],
    'not_started': ['لم يبدأ', 'badge-muted'],
    'draft': ['مسودة', 'badge-warning'],
    'submitted': ['مُرسل', 'badge-success'],
    'reopened': ['مُعاد فتحه', 'badge-info'],
  };
  const [lbl, cls] = map[status] || [status, 'badge-muted'];
  return `<span class="badge ${cls}">${lbl}</span>`;
}

/* ═══════════════════════════════════════════════
   Pages — HR Dashboard
═══════════════════════════════════════════════ */
const Pages = {

  /* ─── HR Dashboard ─── */
  'hr-dashboard': {
    async load(pg) {
      const uid = HRAuth.uid;
      pg.innerHTML = `<div class="loading-msg"><span class="spin"></span> جاري التحميل...</div>`;

      // Get active cycle
      const cycles = await FS.list('cycles', ['where', 'status', '==', 'Active'], ['limit', 1]);
      const cycle = cycles[0] || null;

      // Get my members
      const members = await FS.list('members', ['where', 'assignedHrId', '==', uid], ['where', 'active', '==', true]);

      // Get evaluations in current cycle
      let evals = [];
      if (cycle) {
        evals = await FS.list('evaluations', ['where', 'hrId', '==', uid], ['where', 'cycleId', '==', cycle.id]);
      }

      const submitted = evals.filter(e => e.status === 'submitted').length;
      const pending = evals.filter(e => e.status !== 'submitted').length;
      const total = members.length;

      pg.innerHTML = `
        <div class="sec-head">
          <h2>🏠 مرحبًا، ${encStr(HRAuth.name)}</h2>
        </div>

        ${cycle ? `
        <div class="deadline-widget" style="margin-bottom:24px">
          <span style="font-size:1.5rem">⏰</span>
          <div>
            <div style="font-weight:700;color:var(--text)">${encStr(cycle.name)}</div>
            <div style="font-size:.8rem;color:var(--dim)">الموعد النهائي: ${fmtDate(cycle.deadline)}</div>
          </div>
          <div class="deadline-timer" style="margin-right:auto">${deadlineCountdown(cycle.deadline)}</div>
        </div>` : `
        <div class="card" style="margin-bottom:24px;text-align:center;color:var(--muted)">
          <div style="font-size:2rem;margin-bottom:8px">💤</div>
          <div>لا توجد دورة تقييم نشطة حالياً</div>
        </div>`}

        <div class="grid grid-3" style="margin-bottom:24px">
          <div class="stat-card blue">
            <span class="stat-ico">👥</span>
            <span class="stat-lbl">أعضائي</span>
            <span class="stat-val">${total}</span>
          </div>
          <div class="stat-card green">
            <span class="stat-ico">✅</span>
            <span class="stat-lbl">مكتمل</span>
            <span class="stat-val">${submitted}</span>
          </div>
          <div class="stat-card orange">
            <span class="stat-ico">⏳</span>
            <span class="stat-lbl">معلّق</span>
            <span class="stat-val">${pending}</span>
          </div>
        </div>

        ${total > 0 && cycle ? `
        <div class="card" style="margin-bottom:24px">
          <div class="sec-head" style="margin-bottom:16px">
            <h2 style="font-size:.95rem">📊 تقدم التقييمات</h2>
            <div class="actions">
              <button class="btn btn-primary btn-sm" onclick="App.setSection('hr-evaluate')">ابدأ التقييم ←</button>
            </div>
          </div>
          <div class="progress-wrap" style="margin-bottom:8px">
            <div class="progress-fill" style="width:${total > 0 ? Math.round(submitted/total*100) : 0}%"></div>
          </div>
          <div style="font-size:.8rem;color:var(--dim)">${submitted} من ${total} مكتمل (${total > 0 ? Math.round(submitted/total*100) : 0}%)</div>
        </div>

        <div class="card">
          <div class="sec-head" style="margin-bottom:14px">
            <h2 style="font-size:.95rem">👥 قائمة أعضائي</h2>
          </div>
          <div style="display:flex;flex-direction:column;gap:10px">
            ${members.map(m => {
              const ev = evals.find(e => e.memberId === m.id);
              return `
              <div class="member-card" onclick="Pages['hr-evaluate'].openEval('${m.id}','${encStr(cycle.id)}')">
                <div class="member-avatar">👤</div>
                <div style="flex:1">
                  <div class="member-name">${encStr(m.name)}</div>
                  <div class="member-committee">${encStr(m.committee)}</div>
                </div>
                ${ev ? statusBadge(ev.status) : statusBadge('not_started')}
              </div>`;
            }).join('')}
          </div>
        </div>` : (total === 0 ? `
        <div class="empty">
          <span class="ico">👥</span>
          <p>لم يُعيَّن لك أعضاء بعد.<br>تواصل مع الأدمن.</p>
        </div>` : '')}
      `;
    }
  },

  /* ─── HR Evaluate Page ─── */
  'hr-evaluate': {
    _selectedMember: null,
    _cycleId: null,
    _evalData: null,
    _snapshot: null,
    _scores: {},       // criterionId -> {rating?, score?}
    _bonusApplied: [], // [{ruleId, ruleName, points, count, reason?}]
    _penaltyApplied: [],

    async load(pg) {
      const uid = HRAuth.uid;
      const cycles = await FS.list('cycles', ['where', 'status', '==', 'Active'], ['limit', 1]);
      const cycle = cycles[0];
      if (!cycle) {
        pg.innerHTML = `<div class="empty"><span class="ico">💤</span><p>لا توجد دورة تقييم نشطة.</p></div>`;
        return;
      }
      const members = await FS.list('members', ['where', 'assignedHrId', '==', uid], ['where', 'active', '==', true]);
      const evals = await FS.list('evaluations', ['where', 'hrId', '==', uid], ['where', 'cycleId', '==', cycle.id]);

      pg.innerHTML = `
        <div class="sec-head">
          <h2>📝 تقييم الأعضاء — ${encStr(cycle.name)}</h2>
        </div>
        <div style="display:flex;flex-direction:column;gap:10px">
          ${members.length === 0 ? '<div class="empty"><span class="ico">👥</span><p>لا يوجد أعضاء.</p></div>' :
            members.map(m => {
              const ev = evals.find(e => e.memberId === m.id);
              const isLocked = ev && ev.status === 'submitted' && cycle.status !== 'Closed';
              return `
              <div class="member-card" onclick="Pages['hr-evaluate'].openEval('${m.id}','${cycle.id}')">
                <div class="member-avatar">👤</div>
                <div style="flex:1">
                  <div class="member-name">${encStr(m.name)}</div>
                  <div class="member-committee">${encStr(m.committee)}</div>
                </div>
                <div style="display:flex;align-items:center;gap:8px">
                  ${ev ? statusBadge(ev.status) : statusBadge('not_started')}
                  ${isLocked ? `<span style="font-size:.75rem;color:var(--muted)">🔒</span>` : ''}
                </div>
              </div>`;
            }).join('')}
        </div>
      `;
    },

    async openEval(memberId, cycleId) {
      this._selectedMember = memberId;
      this._cycleId = cycleId;
      this._scores = {};
      this._bonusApplied = [];
      this._penaltyApplied = [];

      const pg = document.getElementById('pg-hr-evaluate');
      pg.innerHTML = `<div class="loading-msg"><span class="spin"></span> جاري تحميل التقييم...</div>`;
      App.cur = 'hr-evaluate';

      const [member, cycle, evalDoc] = await Promise.all([
        FS.get('members', memberId),
        FS.get('cycles', cycleId),
        db.collection('evaluations').doc(`${cycleId}_${memberId}`).get().then(s => s.exists ? {id:s.id,...s.data()} : null)
      ]);

      const snapshot = cycle?.configSnapshot || {};
      this._snapshot = snapshot;
      this._evalData = evalDoc;

      const isLocked = evalDoc && evalDoc.status === 'submitted';
      const isReopened = evalDoc && evalDoc.status === 'reopened';

      // Load existing scores
      if (evalDoc?.criteriaResults) {
        evalDoc.criteriaResults.forEach(cr => {
          this._scores[cr.criterionId] = { rating: cr.rating, score: cr.score };
        });
      }
      if (evalDoc?.bonusApplied) this._bonusApplied = [...evalDoc.bonusApplied];
      if (evalDoc?.penaltyApplied) this._penaltyApplied = [...evalDoc.penaltyApplied];

      const criteria = (snapshot.criteria || []).filter(c => c.active !== false);
      const bonusRules = (snapshot.bonusRules || []).filter(r => r.active !== false);
      const penaltyRules = (snapshot.penaltyRules || []).filter(r => r.active !== false);

      pg.innerHTML = `
        <div class="sec-head">
          <button class="btn btn-ghost btn-sm" onclick="Pages['hr-evaluate'].backToList()">← رجوع</button>
          <h2>📝 تقييم: ${encStr(member?.name || memberId)}</h2>
          ${isLocked ? '<span class="badge badge-success">🔒 مُرسل</span>' : ''}
          ${isReopened ? '<span class="badge badge-warning">🔓 مُعاد فتحه</span>' : ''}
        </div>
        <div style="color:var(--dim);font-size:.8rem;margin-bottom:20px">
          اللجنة: ${encStr(member?.committee)} | الدورة: ${encStr(cycle?.name)}
        </div>

        ${isLocked ? `
        <div class="card" style="border-color:rgba(16,185,129,.3);margin-bottom:20px">
          <div style="text-align:center;color:var(--success)">✅ تم إرسال هذا التقييم وإقفاله. للتعديل، أرسل طلب إعادة فتح.</div>
          <div style="text-align:center;margin-top:12px">
            <button class="btn btn-warning btn-sm" onclick="Pages['hr-evaluate'].requestReopen('${cycleId}_${memberId}')">🔓 طلب إعادة فتح</button>
          </div>
        </div>
        ${this._renderEvalReadonly(evalDoc, criteria, bonusRules, penaltyRules)}
        ` : `
        <form id="eval-form" onsubmit="return false">
          <!-- Criteria -->
          <div class="card" style="margin-bottom:16px">
            <div class="sec-head" style="margin-bottom:14px"><h2 style="font-size:.95rem">📐 معايير التقييم</h2></div>
            ${criteria.length === 0 ? '<div style="color:var(--muted);text-align:center;padding:16px">لا توجد معايير في هذه الدورة</div>' :
              criteria.map(c => this._renderCriterion(c, isLocked)).join('')}
          </div>

          <!-- Bonus -->
          ${bonusRules.length > 0 ? `
          <div class="card" style="margin-bottom:16px">
            <div class="sec-head" style="margin-bottom:14px"><h2 style="font-size:.95rem">⭐ المكافآت</h2></div>
            <div style="display:flex;flex-direction:column;gap:8px" id="bonus-list">
              ${bonusRules.map(r => this._renderRuleSelector(r, 'bonus')).join('')}
            </div>
          </div>` : ''}

          <!-- Penalty -->
          ${penaltyRules.length > 0 ? `
          <div class="card" style="margin-bottom:16px">
            <div class="sec-head" style="margin-bottom:14px"><h2 style="font-size:.95rem">⚠️ الخصومات</h2></div>
            <div style="display:flex;flex-direction:column;gap:8px" id="penalty-list">
              ${penaltyRules.map(r => this._renderRuleSelector(r, 'penalty')).join('')}
            </div>
          </div>` : ''}

          <!-- Overall Note -->
          <div class="card" style="margin-bottom:16px">
            <div class="sec-head" style="margin-bottom:14px"><h2 style="font-size:.95rem">📌 ملاحظة عامة</h2></div>
            <div class="form-group">
              <textarea id="overall-note" placeholder="أضف ملاحظاتك العامة عن العضو في هذه الدورة..." rows="4">${encStr(evalDoc?.overallNote || '')}</textarea>
            </div>
          </div>

          <!-- Preview Score -->
          <div id="score-preview" style="margin-bottom:16px"></div>

          <!-- Actions -->
          <div style="display:flex;gap:12px;flex-wrap:wrap">
            <button class="btn btn-ghost" onclick="Pages['hr-evaluate'].saveDraft()" type="button">
              💾 حفظ كمسودة
            </button>
            <button class="btn btn-primary" onclick="Pages['hr-evaluate'].submit()" type="button">
              ✅ إرسال التقييم النهائي
            </button>
            <button class="btn btn-ghost btn-sm" onclick="Pages['hr-evaluate'].previewScore()" type="button" style="margin-right:auto">
              👁️ معاينة النتيجة
            </button>
          </div>
        </form>`}
      `;

      // Init event listeners for score preview
      if (!isLocked) {
        pg.querySelectorAll('.rating-btn').forEach(btn => {
          btn.addEventListener('click', () => {
            const cId = btn.dataset.cid;
            const val = parseInt(btn.dataset.val);
            this._scores[cId] = { rating: val };
            pg.querySelectorAll(`.rating-btn[data-cid="${cId}"]`).forEach(b => b.classList.toggle('active', parseInt(b.dataset.val) === val));
            // Show auto note
            const c = criteria.find(c => c.id === cId);
            if (c?.ratingNotes && c.ratingNotes[val]) {
              const noteEl = pg.querySelector(`.auto-note[data-cid="${cId}"]`);
              if (noteEl) { noteEl.textContent = c.ratingNotes[val]; noteEl.classList.add('show'); }
            }
            this.previewScore();
          });
        });
        pg.querySelectorAll('.score-direct').forEach(inp => {
          inp.addEventListener('input', () => {
            const cId = inp.dataset.cid;
            const max = parseFloat(inp.dataset.max);
            let val = parseFloat(inp.value) || 0;
            if (val < 0) { val = 0; inp.value = 0; }
            if (val > max) { val = max; inp.value = max; }
            this._scores[cId] = { score: val };
            this.previewScore();
          });
        });

        // Restore existing scores
        Object.entries(this._scores).forEach(([cId, s]) => {
          if (s.rating != null) {
            pg.querySelectorAll(`.rating-btn[data-cid="${cId}"]`).forEach(b => b.classList.toggle('active', parseInt(b.dataset.val) === s.rating));
            const c = criteria.find(c => c.id === cId);
            if (c?.ratingNotes?.[s.rating]) {
              const noteEl = pg.querySelector(`.auto-note[data-cid="${cId}"]`);
              if (noteEl) { noteEl.textContent = c.ratingNotes[s.rating]; noteEl.classList.add('show'); }
            }
          }
          if (s.score != null) {
            const inp = pg.querySelector(`.score-direct[data-cid="${cId}"]`);
            if (inp) inp.value = s.score;
          }
        });

        // Restore bonus/penalty selections
        this._bonusApplied.forEach(item => this._updateRuleUI(item.ruleId, 'bonus', item.count));
        this._penaltyApplied.forEach(item => this._updateRuleUI(item.ruleId, 'penalty', item.count));

        this.previewScore();
      }
    },

    _renderCriterion(c, locked) {
      const existing = this._scores[c.id] || {};
      if (c.mode === 'rating') {
        const ratingMap = c.ratingMap || {};
        return `
        <div class="criterion-card">
          <div class="criterion-title">${encStr(c.name)} <span style="color:var(--muted);font-size:.75rem">(Max: ${ratingMap[5] || c.maxScore})</span></div>
          ${c.description ? `<div class="criterion-desc">${encStr(c.description)}</div>` : ''}
          <div class="rating-stars">
            ${[1,2,3,4,5].map(v => `
              <button class="rating-btn ${existing.rating === v ? 'active' : ''}" 
                      data-cid="${c.id}" data-val="${v}" type="button" ${locked ? 'disabled' : ''}>
                ${v}
              </button>
              <span style="font-size:.75rem;color:var(--muted);align-self:center">${ratingMap[v] != null ? '→'+ratingMap[v] : ''}</span>
            `).join('')}
          </div>
          <div class="auto-note ${existing.rating && c.ratingNotes?.[existing.rating] ? 'show' : ''}" data-cid="${c.id}">
            ${existing.rating && c.ratingNotes?.[existing.rating] ? encStr(c.ratingNotes[existing.rating]) : ''}
          </div>
        </div>`;
      } else {
        return `
        <div class="criterion-card">
          <div class="criterion-title">${encStr(c.name)} <span style="color:var(--muted);font-size:.75rem">(Max: ${c.maxScore})</span></div>
          ${c.description ? `<div class="criterion-desc">${encStr(c.description)}</div>` : ''}
          <div style="display:flex;align-items:center;gap:10px">
            <input type="number" class="score-direct" data-cid="${c.id}" data-max="${c.maxScore}"
                   min="0" max="${c.maxScore}" step="0.5" placeholder="0" 
                   value="${existing.score ?? ''}" ${locked ? 'readonly' : ''}
                   style="width:100px;text-align:center">
            <span style="color:var(--dim);font-size:.85rem">/ ${c.maxScore}</span>
          </div>
        </div>`;
      }
    },

    _renderRuleSelector(r, type) {
      const applied = type === 'bonus' 
        ? this._bonusApplied.find(x => x.ruleId === r.id)
        : this._penaltyApplied.find(x => x.ruleId === r.id);
      const count = applied?.count || 0;
      const selected = count > 0;
      const cls = selected ? (type === 'bonus' ? 'selected-bonus' : 'selected-penalty') : '';
      return `
      <div class="rule-item ${cls}" id="rule-item-${r.id}">
        <div style="flex:1">
          <div style="font-weight:600;color:var(--text)">${encStr(r.name)}</div>
          <div style="font-size:.78rem;color:var(--dim)">${type === 'bonus' ? '+' : '-'}${r.points} نقطة${r.allowMultiple ? ' (قابلة للتكرار)' : ''}</div>
        </div>
        ${r.allowMultiple ? `
        <div class="rule-count">
          <button type="button" onclick="Pages['hr-evaluate'].changeRuleCount('${r.id}','${type}',-1)">−</button>
          <span id="rcount-${r.id}">${count}</span>
          <button type="button" onclick="Pages['hr-evaluate'].changeRuleCount('${r.id}','${type}',1)">+</button>
        </div>` : `
        <input type="checkbox" style="width:18px;height:18px;cursor:pointer" 
               ${selected ? 'checked' : ''}
               onchange="Pages['hr-evaluate'].toggleRule('${r.id}','${type}','${encStr(r.name)}',${r.points},this.checked)">`}
      </div>`;
    },

    toggleRule(ruleId, type, name, points, checked) {
      const arr = type === 'bonus' ? this._bonusApplied : this._penaltyApplied;
      const idx = arr.findIndex(x => x.ruleId === ruleId);
      if (checked && idx === -1) arr.push({ ruleId, ruleName: name, points, count: 1 });
      if (!checked && idx !== -1) arr.splice(idx, 1);
      const item = document.getElementById(`rule-item-${ruleId}`);
      if (item) item.className = `rule-item ${checked ? (type==='bonus'?'selected-bonus':'selected-penalty') : ''}`;
      this.previewScore();
    },

    changeRuleCount(ruleId, type, delta) {
      const arr = type === 'bonus' ? this._bonusApplied : this._penaltyApplied;
      const snap = this._snapshot;
      const rules = type === 'bonus' ? snap.bonusRules : snap.penaltyRules;
      const rule = (rules || []).find(r => r.id === ruleId);
      const maxTimes = rule?.maxTimes || 99;
      
      let item = arr.find(x => x.ruleId === ruleId);
      if (!item) {
        item = { ruleId, ruleName: rule?.name || ruleId, points: rule?.points || 0, count: 0 };
        arr.push(item);
      }
      item.count = Math.max(0, Math.min(maxTimes, item.count + delta));
      if (item.count === 0) {
        const idx = arr.indexOf(item);
        arr.splice(idx, 1);
      }
      
      const countEl = document.getElementById(`rcount-${ruleId}`);
      if (countEl) countEl.textContent = item.count;
      const el = document.getElementById(`rule-item-${ruleId}`);
      if (el) el.className = `rule-item ${item.count > 0 ? (type==='bonus'?'selected-bonus':'selected-penalty') : ''}`;
      this.previewScore();
    },

    _updateRuleUI(ruleId, type, count) {
      const countEl = document.getElementById(`rcount-${ruleId}`);
      if (countEl) countEl.textContent = count;
      const el = document.getElementById(`rule-item-${ruleId}`);
      if (el) el.className = `rule-item ${count > 0 ? (type==='bonus'?'selected-bonus':'selected-penalty') : ''}`;
    },

    previewScore() {
      const criteria = (this._snapshot?.criteria || []).filter(c => c.active !== false);
      let criteriaTotal = 0;
      criteria.forEach(c => {
        const s = this._scores[c.id] || {};
        if (c.mode === 'rating' && s.rating != null) {
          const ratingMap = c.ratingMap || {};
          criteriaTotal += ratingMap[s.rating] || 0;
        } else if (c.mode === 'direct' && s.score != null) {
          criteriaTotal += parseFloat(s.score) || 0;
        }
      });
      const bonusTotal = this._bonusApplied.reduce((sum, b) => sum + b.points * b.count, 0);
      const penaltyTotal = this._penaltyApplied.reduce((sum, p) => sum + p.points * p.count, 0);
      const finalScore = Math.max(0, criteriaTotal + bonusTotal - penaltyTotal);

      // Determine level
      const levels = (this._snapshot?.levels || []).sort((a, b) => b.minScore - a.minScore);
      const level = levels.find(l => finalScore >= l.minScore);

      const previewEl = document.getElementById('score-preview');
      if (!previewEl) return;
      previewEl.innerHTML = `
        <div class="score-summary">
          <div style="font-weight:700;color:var(--text);margin-bottom:12px">👁️ معاينة النتيجة (Client Preview)</div>
          <div class="score-row"><span>مجموع المعايير</span><span style="font-weight:700">${criteriaTotal.toFixed(1)}</span></div>
          <div class="score-row"><span>المكافآت</span><span style="color:var(--success);font-weight:700">+${bonusTotal}</span></div>
          <div class="score-row"><span>الخصومات</span><span style="color:var(--danger);font-weight:700">-${penaltyTotal}</span></div>
          <div class="score-row total">
            <span>الدرجة النهائية (Preview)</span>
            <span style="color:var(--primary);font-size:1.3rem">${finalScore.toFixed(1)}</span>
          </div>
          ${level ? `<div style="margin-top:12px;text-align:center">
            <span class="level-badge" style="background:${level.color || '#6366f1'}22;color:${level.color || '#a5b4fc'};border:1px solid ${level.color || '#6366f1'}44">
              ${encStr(level.name)}
            </span>
            ${level.finalNote ? `<div style="color:var(--dim);font-size:.78rem;margin-top:6px">${encStr(level.finalNote)}</div>` : ''}
          </div>` : ''}
          <div style="color:var(--muted);font-size:.72rem;margin-top:8px;text-align:center">* الحساب الفعلي يتم Server-side عند الإرسال</div>
        </div>
      `;
    },

    _renderEvalReadonly(evalDoc, criteria) {
      if (!evalDoc) return '';
      return `
        <div class="score-summary">
          <div style="font-weight:700;color:var(--text);margin-bottom:12px">📊 نتيجة التقييم</div>
          <div class="score-row"><span>مجموع المعايير</span><span style="font-weight:700">${evalDoc.criteriaTotal?.toFixed(1) || '—'}</span></div>
          <div class="score-row"><span>المكافآت</span><span style="color:var(--success);font-weight:700">+${evalDoc.bonusTotal || 0}</span></div>
          <div class="score-row"><span>الخصومات</span><span style="color:var(--danger);font-weight:700">-${evalDoc.penaltyTotal || 0}</span></div>
          <div class="score-row total"><span>الدرجة النهائية</span><span style="color:var(--primary);font-size:1.3rem">${evalDoc.finalScore?.toFixed(1) || '—'}</span></div>
          ${evalDoc.levelName ? `<div style="margin-top:10px;text-align:center">
            <span class="badge badge-primary" style="font-size:.85rem">${encStr(evalDoc.levelName)}</span>
          </div>` : ''}
        </div>
        <div class="card">
          <div style="font-weight:700;margin-bottom:12px">📐 تفاصيل المعايير</div>
          ${(evalDoc.criteriaResults || []).map(cr => `
          <div style="display:flex;justify-content:space-between;padding:8px 0;border-bottom:1px solid var(--border)">
            <div>
              <div style="font-weight:600">${encStr(cr.name)}</div>
              ${cr.autoNote ? `<div style="font-size:.78rem;color:var(--dim)">${encStr(cr.autoNote)}</div>` : ''}
            </div>
            <span style="font-weight:700;color:var(--primary)">${cr.score?.toFixed(1) || '—'}</span>
          </div>`).join('')}
        </div>
        ${evalDoc.overallNote ? `<div class="card" style="margin-top:12px"><strong>ملاحظة عامة:</strong><div style="color:var(--dim);margin-top:6px">${encStr(evalDoc.overallNote)}</div></div>` : ''}
        <div style="color:var(--muted);font-size:.78rem;margin-top:10px;text-align:center">أُرسل في: ${fmtDatetime(evalDoc.submittedAt)}</div>
      `;
    },

    backToList() {
      this._selectedMember = null;
      this._cycleId = null;
      App.setSection('hr-evaluate');
    },

    _buildSubmitPayload() {
      const criteria = (this._snapshot?.criteria || []).filter(c => c.active !== false);
      const criteriaResults = criteria.map(c => {
        const s = this._scores[c.id] || {};
        return {
          criterionId: c.id,
          name: c.name,
          mode: c.mode,
          max: c.mode === 'rating' ? (c.ratingMap?.[5] || c.maxScore) : c.maxScore,
          rating: s.rating ?? null,
          score: s.score ?? null,
          autoNote: null, // will be set server-side
        };
      });
      return {
        cycleId: this._cycleId,
        memberId: this._selectedMember,
        criteriaResults,
        bonusApplied: this._bonusApplied,
        penaltyApplied: this._penaltyApplied,
        overallNote: document.getElementById('overall-note')?.value?.trim() || '',
      };
    },

    async saveDraft() {
      const payload = this._buildSubmitPayload();
      try {
        const saveDraft = functions.httpsCallable('saveEvaluationDraft');
        await saveDraft(payload);
        Toast.show('تم حفظ المسودة بنجاح', 'success');
      } catch(e) {
        Toast.show('فشل الحفظ: ' + e.message, 'error');
      }
    },

    async submit() {
      const ok = await Modal.open('إرسال التقييم النهائي',
        '<p style="color:var(--dim)">بعد الإرسال لن تستطيع التعديل إلا عبر طلب إعادة الفتح. هل أنت متأكد؟</p>',
        '✅ إرسال', false);
      if (!ok) return;

      const payload = this._buildSubmitPayload();
      try {
        const submitEval = functions.httpsCallable('submitEvaluation');
        const result = await submitEval(payload);
        Toast.show('✅ تم إرسال التقييم بنجاح!', 'success');
        // Reload eval page to show locked view
        await this.openEval(this._selectedMember, this._cycleId);
      } catch(e) {
        Toast.show('فشل الإرسال: ' + e.message, 'error');
      }
    },

    async requestReopen(evalId) {
      const reason = await Modal.prompt('طلب إعادة فتح التقييم', 'اكتب سبب طلب إعادة الفتح...', 'إرسال الطلب');
      if (!reason) return;
      try {
        const req = functions.httpsCallable('requestEvalReopen');
        await req({ evaluationId: evalId, reason });
        Toast.show('تم إرسال طلب إعادة الفتح', 'success');
      } catch(e) {
        Toast.show('فشل: ' + e.message, 'error');
      }
    }
  },

  /* ─── HR History ─── */
  'hr-history': {
    async load(pg) {
      const uid = HRAuth.uid;
      pg.innerHTML = `<div class="loading-msg"><span class="spin"></span></div>`;
      const members = await FS.list('members', ['where', 'assignedHrId', '==', uid]);
      const memberMap = {};
      members.forEach(m => memberMap[m.id] = m);

      const evals = await FS.list('evaluations', ['where', 'hrId', '==', uid], ['orderBy', 'submittedAt', 'desc']);

      pg.innerHTML = `
        <div class="sec-head"><h2>📋 سجل التقييمات</h2></div>
        ${evals.length === 0 ? '<div class="empty"><span class="ico">📋</span><p>لا توجد تقييمات بعد.</p></div>' : `
        <div class="card tbl-wrap">
          <table>
            <thead><tr><th>العضو</th><th>اللجنة</th><th>الدورة</th><th>الدرجة</th><th>المستوى</th><th>الحالة</th><th>التاريخ</th></tr></thead>
            <tbody>
              ${evals.map(e => `
              <tr>
                <td><strong>${encStr(e.memberName || e.memberId)}</strong></td>
                <td>${encStr(e.committee || '—')}</td>
                <td>${encStr(e.cycleId || '—')}</td>
                <td style="font-weight:700;color:var(--primary)">${e.finalScore != null ? e.finalScore.toFixed(1) : '—'}</td>
                <td>${e.levelName ? `<span class="badge badge-primary">${encStr(e.levelName)}</span>` : '—'}</td>
                <td>${statusBadge(e.status)}</td>
                <td style="font-size:.8rem">${fmtDate(e.submittedAt)}</td>
              </tr>`).join('')}
            </tbody>
          </table>
        </div>`}
      `;
    }
  },

  /* ─── Admin Dashboard ─── */
  'admin-dashboard': {
    async load(pg) {
      pg.innerHTML = `<div class="loading-msg"><span class="spin"></span> جاري التحميل...</div>`;
      const isHead = HRAuth.role === 'head';
      const uid = HRAuth.uid;

      let membersQ = isHead
        ? ['where', 'headId', '==', uid]
        : null;
      let hrsQ = isHead
        ? ['where', 'headId', '==', uid]
        : null;

      const [cycles, allMembers, allHRs, allEvals] = await Promise.all([
        FS.list('cycles', ['orderBy', 'createdAt', 'desc'], ['limit', 5]),
        membersQ ? FS.list('members', membersQ) : FS.list('members'),
        hrsQ ? FS.list('users', ['where', 'role', '==', 'hr'], hrsQ) : FS.list('users', ['where', 'role', '==', 'hr']),
        isHead
          ? FS.list('evaluations', ['where', 'headId', '==', uid])
          : FS.list('evaluations')
      ]);

      const activeCycle = cycles.find(c => c.status === 'Active');
      const activeMembers = allMembers.filter(m => m.active);
      const inactiveMembers = allMembers.filter(m => !m.active);
      const cycleEvals = activeCycle ? allEvals.filter(e => e.cycleId === activeCycle.id) : [];
      const submitted = cycleEvals.filter(e => e.status === 'submitted').length;
      const pending = cycleEvals.filter(e => e.status !== 'submitted').length;
      const progress = cycleEvals.length > 0 ? Math.round(submitted / cycleEvals.length * 100) : 0;

      pg.innerHTML = `
        <div class="sec-head"><h2>📊 لوحة الإدارة</h2></div>

        <!-- Stats -->
        <div class="grid grid-4" style="margin-bottom:24px">
          <div class="stat-card blue">
            <span class="stat-ico">👥</span>
            <span class="stat-lbl">أعضاء نشطون</span>
            <span class="stat-val">${activeMembers.length}</span>
            <span class="stat-sub">${inactiveMembers.length} غير نشط</span>
          </div>
          <div class="stat-card green">
            <span class="stat-ico">🧑‍💼</span>
            <span class="stat-lbl">HR Members</span>
            <span class="stat-val">${allHRs.length}</span>
          </div>
          <div class="stat-card orange">
            <span class="stat-ico">✅</span>
            <span class="stat-lbl">مكتمل (الدورة الحالية)</span>
            <span class="stat-val">${submitted}</span>
          </div>
          <div class="stat-card pink">
            <span class="stat-ico">⏳</span>
            <span class="stat-lbl">معلّق</span>
            <span class="stat-val">${pending}</span>
          </div>
        </div>

        <!-- Current Cycle -->
        ${activeCycle ? `
        <div class="card" style="margin-bottom:20px">
          <div class="sec-head" style="margin-bottom:12px">
            <h2 style="font-size:.95rem">🔄 الدورة الحالية</h2>
            <div class="actions">
              <button class="btn btn-ghost btn-sm" onclick="App.setSection('cycles')">عرض الكل</button>
            </div>
          </div>
          <div style="display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:12px">
            <div>
              <div style="font-weight:700;font-size:1.05rem">${encStr(activeCycle.name)}</div>
              <div style="color:var(--dim);font-size:.82rem">${fmtDate(activeCycle.startDate)} ← الموعد النهائي: ${fmtDate(activeCycle.deadline)}</div>
            </div>
            <div class="deadline-timer">${deadlineCountdown(activeCycle.deadline)}</div>
          </div>
          <div style="margin-top:14px">
            <div style="display:flex;justify-content:space-between;font-size:.8rem;color:var(--dim);margin-bottom:6px">
              <span>التقدم الكلي</span><span>${progress}% (${submitted}/${cycleEvals.length})</span>
            </div>
            <div class="progress-wrap"><div class="progress-fill" style="width:${progress}%"></div></div>
          </div>
        </div>` : `
        <div class="card" style="margin-bottom:20px;text-align:center;color:var(--muted)">
          <div style="font-size:2rem;margin-bottom:8px">💤</div>
          <div>لا توجد دورة نشطة</div>
          <button class="btn btn-primary btn-sm" style="margin-top:12px" onclick="App.setSection('cycles')">إنشاء دورة جديدة</button>
        </div>`}

        <!-- HR Progress -->
        ${allHRs.length > 0 && activeCycle ? `
        <div class="card" style="margin-bottom:20px">
          <div class="sec-head" style="margin-bottom:14px"><h2 style="font-size:.95rem">🧑‍💼 تقدم كل HR</h2></div>
          ${allHRs.map(hr => {
            const hrEvals = cycleEvals.filter(e => e.hrId === hr.id);
            const hrSubmitted = hrEvals.filter(e => e.status === 'submitted').length;
            const hrTotal = hrEvals.length;
            const hrPct = hrTotal > 0 ? Math.round(hrSubmitted / hrTotal * 100) : 0;
            return `
            <div style="margin-bottom:14px">
              <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:6px">
                <span style="font-weight:600">${encStr(hr.name)}</span>
                <span style="font-size:.8rem;color:var(--dim)">${hrSubmitted}/${hrTotal} (${hrPct}%)</span>
              </div>
              <div class="progress-wrap"><div class="progress-fill" style="width:${hrPct}%"></div></div>
            </div>`;
          }).join('')}
        </div>` : ''}

        <!-- Quick Actions -->
        <div class="grid grid-2">
          <div class="card" style="cursor:pointer" onclick="App.setSection('members-mgmt')">
            <div style="font-size:1.5rem;margin-bottom:8px">👥</div>
            <div style="font-weight:700">إدارة الأعضاء</div>
            <div style="color:var(--dim);font-size:.8rem">${activeMembers.length} عضو نشط</div>
          </div>
          <div class="card" style="cursor:pointer" onclick="App.setSection('evaluations-list')">
            <div style="font-size:1.5rem;margin-bottom:8px">📝</div>
            <div style="font-weight:700">عرض التقييمات</div>
            <div style="color:var(--dim);font-size:.8rem">${cycleEvals.length} تقييم في الدورة الحالية</div>
          </div>
        </div>
      `;
    }
  },

  /* ─── Members Management ─── */
  'members-mgmt': {
    async load(pg) {
      pg.innerHTML = `<div class="loading-msg"><span class="spin"></span></div>`;
      const members = await FS.list('members', ['orderBy', 'createdAt', 'desc']);
      const hrs = await FS.list('users', ['where', 'role', '==', 'hr']);
      const hrMap = {};
      hrs.forEach(h => hrMap[h.id] = h.name);

      pg.innerHTML = `
        <div class="sec-head">
          <h2>👥 الأعضاء</h2>
          <div class="actions">
            <button class="btn btn-primary" onclick="Pages['members-mgmt'].addModal()">+ إضافة عضو</button>
          </div>
        </div>
        <div class="filters">
          <input id="member-search" placeholder="بحث..." oninput="Pages['members-mgmt'].filter()" style="max-width:200px">
          <select id="member-status-filter" onchange="Pages['members-mgmt'].filter()">
            <option value="">كل الحالات</option>
            <option value="active">نشط</option>
            <option value="inactive">غير نشط</option>
          </select>
        </div>
        <div class="card tbl-wrap">
          <table id="members-table">
            <thead><tr><th>الاسم</th><th>اللجنة</th><th>الـ HR المسؤول</th><th>الحالة</th><th>تاريخ الإضافة</th><th>إجراء</th></tr></thead>
            <tbody id="members-tbody">
              ${members.map(m => this._row(m, hrMap)).join('')}
            </tbody>
          </table>
        </div>
      `;
      this._members = members;
      this._hrMap = hrMap;
    },
    _members: [],
    _hrMap: {},
    _row(m, hrMap) {
      return `<tr data-active="${m.active ? 'active' : 'inactive'}" data-name="${encStr(m.name).toLowerCase()}">
        <td><strong>${encStr(m.name)}</strong></td>
        <td>${encStr(m.committee || '—')}</td>
        <td>${encStr(hrMap[m.assignedHrId] || '—')}</td>
        <td>${m.active ? '<span class="badge badge-success">نشط</span>' : '<span class="badge badge-muted">غير نشط</span>'}</td>
        <td style="font-size:.8rem">${fmtDate(m.createdAt)}</td>
        <td>
          <div style="display:flex;gap:4px">
            <button class="btn btn-ghost btn-xs" onclick="Pages['members-mgmt'].editModal('${m.id}')">✏️</button>
            <button class="btn btn-${m.active?'warning':'success'} btn-xs" onclick="Pages['members-mgmt'].toggleActive('${m.id}',${m.active})">${m.active?'تعطيل':'تفعيل'}</button>
          </div>
        </td>
      </tr>`;
    },
    filter() {
      const q = document.getElementById('member-search')?.value.toLowerCase() || '';
      const st = document.getElementById('member-status-filter')?.value || '';
      document.querySelectorAll('#members-tbody tr').forEach(tr => {
        const nameMatch = !q || tr.dataset.name?.includes(q);
        const stMatch = !st || tr.dataset.active === st;
        tr.style.display = nameMatch && stMatch ? '' : 'none';
      });
    },
    async addModal() {
      const hrs = this._hrMap;
      const hrOpts = Object.entries(hrs).map(([id, n]) => `<option value="${id}">${encStr(n)}</option>`).join('');
      const ok = await Modal.open('+ إضافة عضو جديد', `
        <div class="form-row cols-2">
          <div class="form-group"><label>الاسم</label><input id="m-name" placeholder="اسم العضو"></div>
          <div class="form-group"><label>اللجنة</label><input id="m-committee" placeholder="اسم اللجنة"></div>
        </div>
        <div class="form-group"><label>الـ HR المسؤول</label>
          <select id="m-hr"><option value="">— اختر الـ HR —</option>${hrOpts}</select>
        </div>
      `, 'إضافة');
      if (!ok) return;
      const name = document.getElementById('m-name').value.trim();
      const committee = document.getElementById('m-committee').value.trim();
      const hrId = document.getElementById('m-hr').value;
      if (!name) { Toast.show('أدخل اسم العضو', 'error'); return; }

      // Get headId from HR's record
      let headId = '';
      if (hrId) {
        const hrDoc = await FS.get('users', hrId);
        headId = hrDoc?.headId || '';
      }

      try {
        const addMember = functions.httpsCallable('addMember');
        await addMember({ name, committee, assignedHrId: hrId, headId });
        Toast.show('تم إضافة العضو', 'success');
        this.load(document.getElementById('pg-members-mgmt'));
      } catch(e) {
        Toast.show('فشل: ' + e.message, 'error');
      }
    },
    async editModal(memberId) {
      const m = this._members.find(x => x.id === memberId);
      if (!m) return;
      const hrs = this._hrMap;
      const hrOpts = Object.entries(hrs).map(([id, n]) => `<option value="${id}" ${m.assignedHrId === id ? 'selected' : ''}>${encStr(n)}</option>`).join('');
      const ok = await Modal.open('✏️ تعديل العضو', `
        <div class="form-row cols-2">
          <div class="form-group"><label>الاسم</label><input id="m-name" value="${encStr(m.name)}"></div>
          <div class="form-group"><label>اللجنة</label><input id="m-committee" value="${encStr(m.committee || '')}"></div>
        </div>
        <div class="form-group"><label>الـ HR المسؤول</label>
          <select id="m-hr"><option value="">— بدون تعيين —</option>${hrOpts}</select>
        </div>
      `, 'حفظ التعديلات');
      if (!ok) return;
      const name = document.getElementById('m-name').value.trim();
      const committee = document.getElementById('m-committee').value.trim();
      const hrId = document.getElementById('m-hr').value;
      try {
        await FS.update('members', memberId, { name, committee, assignedHrId: hrId });
        Toast.show('تم التعديل', 'success');
        this.load(document.getElementById('pg-members-mgmt'));
      } catch(e) { Toast.show('فشل: ' + e.message, 'error'); }
    },
    async toggleActive(memberId, currentActive) {
      try {
        await FS.update('members', memberId, {
          active: !currentActive,
          deactivatedAt: !currentActive ? null : FS.ts()
        });
        Toast.show(currentActive ? 'تم تعطيل العضو' : 'تم تفعيل العضو', 'success');
        this.load(document.getElementById('pg-members-mgmt'));
      } catch(e) { Toast.show('فشل: ' + e.message, 'error'); }
    }
  },

  /* ─── HR Management ─── */
  'hr-mgmt': {
    async load(pg) {
      pg.innerHTML = `<div class="loading-msg"><span class="spin"></span></div>`;
      const hrs = await FS.list('users', ['where', 'role', '==', 'hr']);
      const heads = await FS.list('users', ['where', 'role', '==', 'head']);
      const headMap = {};
      heads.forEach(h => headMap[h.id] = h.name);

      pg.innerHTML = `
        <div class="sec-head">
          <h2>🧑‍💼 إدارة الـ HR</h2>
          ${HRAuth.isSuperAdmin() ? '<div class="actions"><button class="btn btn-primary" onclick="Pages[\'hr-mgmt\'].addModal()">+ إضافة HR</button></div>' : ''}
        </div>
        <div class="card tbl-wrap">
          <table>
            <thead><tr><th>الاسم</th><th>الـ Head المسؤول</th><th>الحالة</th><th>إجراء</th></tr></thead>
            <tbody>
              ${hrs.length === 0 ? '<tr><td colspan="4" style="text-align:center;color:var(--muted)">لا يوجد HR members بعد</td></tr>' :
                hrs.map(hr => `<tr>
                  <td><strong>${encStr(hr.name)}</strong><div style="font-size:.75rem;color:var(--muted)">${hr.id}</div></td>
                  <td>${encStr(headMap[hr.headId] || '—')}</td>
                  <td>${hr.active !== false ? '<span class="badge badge-success">نشط</span>' : '<span class="badge badge-muted">معطّل</span>'}</td>
                  <td>
                    ${HRAuth.isSuperAdmin() ? `
                    <div style="display:flex;gap:4px">
                      <button class="btn btn-ghost btn-xs" onclick="Pages['hr-mgmt'].manageCode('${hr.id}','${encStr(hr.name)}')">🔑 الكود</button>
                      <button class="btn btn-${hr.active !== false ? 'warning' : 'success'} btn-xs" onclick="Pages['hr-mgmt'].toggleActive('${hr.id}',${hr.active !== false})">${hr.active !== false ? 'تعطيل' : 'تفعيل'}</button>
                    </div>` : '—'}
                  </td>
                </tr>`).join('')}
            </tbody>
          </table>
        </div>
      `;
      this._hrs = hrs;
    },
    _hrs: [],
    async addModal() {
      const heads = await FS.list('users', ['where', 'role', '==', 'head']);
      const headOpts = heads.map(h => `<option value="${h.id}">${encStr(h.name)}</option>`).join('');
      const ok = await Modal.open('+ إضافة HR Member', `
        <div class="form-group"><label>الاسم</label><input id="hr-name" placeholder="اسم الـ HR"></div>
        <div class="form-group"><label>الـ Head المسؤول</label>
          <select id="hr-head"><option value="">— بدون head —</option>${headOpts}</select>
        </div>
        <div style="background:var(--surface2);border-radius:8px;padding:12px;color:var(--dim);font-size:.8rem;margin-top:8px">
          ⚠️ بعد الإضافة، سيتم إنشاء رمز وصول تلقائيًا ويُعرض مرة واحدة فقط.
        </div>
      `, 'إنشاء HR');
      if (!ok) return;
      const name = document.getElementById('hr-name').value.trim();
      const headId = document.getElementById('hr-head').value;
      if (!name) { Toast.show('أدخل الاسم', 'error'); return; }
      try {
        const createHR = functions.httpsCallable('createHRUser');
        const result = await createHR({ name, headId, role: 'hr' });
        const code = result.data?.accessCode;
        await Modal.open('✅ تم إنشاء حساب الـ HR', `
          <div style="text-align:center">
            <div style="font-size:2rem;margin-bottom:8px">🎉</div>
            <p style="color:var(--dim);margin-bottom:16px">تم إنشاء حساب <strong style="color:var(--text)">${encStr(name)}</strong></p>
            <div style="background:var(--surface2);border:2px dashed var(--primary);border-radius:10px;padding:16px;margin-bottom:12px">
              <div style="font-size:.75rem;color:var(--dim);margin-bottom:6px">رمز الوصول (يُعرض مرة واحدة فقط)</div>
              <div style="font-size:1.4rem;font-weight:900;color:var(--primary);letter-spacing:.15em;font-family:monospace">${encStr(code || '—')}</div>
            </div>
            <p style="color:var(--danger);font-size:.78rem">⚠️ احفظ هذا الرمز الآن. لن يظهر مرة أخرى.</p>
          </div>
        `, 'حسنًا، تم الحفظ', false);
        this.load(document.getElementById('pg-hr-mgmt'));
      } catch(e) { Toast.show('فشل: ' + e.message, 'error'); }
    },
    async manageCode(hrId, hrName) {
      const ok = await Modal.open(`🔑 إدارة كود "${hrName}"`, `
        <p style="color:var(--dim);margin-bottom:16px">اختر الإجراء المطلوب على رمز وصول هذا الـ HR.</p>
        <div style="display:flex;flex-direction:column;gap:8px">
          <button class="btn btn-warning" onclick="Pages['hr-mgmt']._rotateCode('${hrId}')">🔄 تدوير الكود (إنشاء جديد)</button>
          <button class="btn btn-danger" onclick="Pages['hr-mgmt']._disableCode('${hrId}')">🚫 تعطيل الكود</button>
        </div>
      `, 'إغلاق', false);
    },
    async _rotateCode(hrId) {
      Modal.close();
      try {
        const rotate = functions.httpsCallable('rotateAccessCode');
        const result = await rotate({ userId: hrId });
        const code = result.data?.accessCode;
        await Modal.open('✅ تم تدوير الكود', `
          <div style="text-align:center">
            <div style="background:var(--surface2);border:2px dashed var(--primary);border-radius:10px;padding:16px">
              <div style="font-size:.75rem;color:var(--dim);margin-bottom:6px">الكود الجديد</div>
              <div style="font-size:1.4rem;font-weight:900;color:var(--primary);letter-spacing:.15em;font-family:monospace">${encStr(code || '—')}</div>
            </div>
            <p style="color:var(--danger);font-size:.78rem;margin-top:12px">⚠️ احفظه الآن، لن يظهر مرة أخرى.</p>
          </div>
        `, 'حسنًا', false);
      } catch(e) { Toast.show('فشل: ' + e.message, 'error'); }
    },
    async _disableCode(hrId) {
      Modal.close();
      const ok = await Modal.open('تعطيل الكود', '<p style="color:var(--danger)">سيتم تسجيل خروج المستخدم تلقائيًا.</p>', 'تعطيل', true);
      if (!ok) return;
      try {
        const disable = functions.httpsCallable('disableAccessCode');
        await disable({ userId: hrId });
        Toast.show('تم تعطيل الكود', 'success');
      } catch(e) { Toast.show('فشل: ' + e.message, 'error'); }
    },
    async toggleActive(hrId, currentActive) {
      try {
        await FS.update('users', hrId, { active: !currentActive });
        Toast.show(currentActive ? 'تم تعطيل حساب الـ HR' : 'تم تفعيله', 'success');
        this.load(document.getElementById('pg-hr-mgmt'));
      } catch(e) { Toast.show('فشل: ' + e.message, 'error'); }
    }
  },

  /* ─── Assignments ─── */
  'assignments': {
    async load(pg) {
      pg.innerHTML = `<div class="loading-msg"><span class="spin"></span></div>`;
      const [members, hrs] = await Promise.all([
        FS.list('members', ['where', 'active', '==', true], ['orderBy', 'name']),
        FS.list('users', ['where', 'role', '==', 'hr'])
      ]);
      const hrMap = {};
      hrs.forEach(h => hrMap[h.id] = h.name);
      const hrOpts = hrs.map(h => `<option value="${h.id}">${encStr(h.name)}</option>`).join('');

      pg.innerHTML = `
        <div class="sec-head">
          <h2>🔗 التعيينات</h2>
          <div class="actions">
            <button class="btn btn-ghost btn-sm" onclick="Pages['assignments'].load(document.getElementById('pg-assignments'))">🔄 تحديث</button>
          </div>
        </div>
        <div class="card" style="margin-bottom:20px">
          <div style="font-weight:700;margin-bottom:12px">نقل جماعي</div>
          <div class="form-row cols-3">
            <div class="form-group"><label>من الـ HR</label>
              <select id="bulk-from"><option value="">— اختر —</option>${hrOpts}</select>
            </div>
            <div class="form-group"><label>إلى الـ HR</label>
              <select id="bulk-to"><option value="">— اختر —</option>${hrOpts}</select>
            </div>
            <div class="form-group"><label>&nbsp;</label>
              <button class="btn btn-primary" onclick="Pages['assignments'].bulkTransfer()">نقل الكل</button>
            </div>
          </div>
        </div>
        <div class="card tbl-wrap">
          <table>
            <thead><tr><th>العضو</th><th>اللجنة</th><th>الـ HR الحالي</th><th>تغيير الـ HR</th></tr></thead>
            <tbody>
              ${members.map(m => `<tr>
                <td><strong>${encStr(m.name)}</strong></td>
                <td>${encStr(m.committee || '—')}</td>
                <td>${encStr(hrMap[m.assignedHrId] || 'غير معيّن')}</td>
                <td>
                  <div style="display:flex;gap:6px;align-items:center">
                    <select id="assign-${m.id}" style="max-width:160px">
                      <option value="">— اختر —</option>
                      ${hrs.map(h => `<option value="${h.id}" ${m.assignedHrId===h.id?'selected':''}>${encStr(h.name)}</option>`).join('')}
                    </select>
                    <button class="btn btn-primary btn-xs" onclick="Pages['assignments'].assign('${m.id}')">تعيين</button>
                  </div>
                </td>
              </tr>`).join('')}
            </tbody>
          </table>
        </div>
      `;
      this._hrs = hrs;
    },
    _hrs: [],
    async assign(memberId) {
      const newHrId = document.getElementById(`assign-${memberId}`)?.value;
      if (!newHrId) { Toast.show('اختر الـ HR أولاً', 'error'); return; }
      const hr = this._hrs.find(h => h.id === newHrId);
      try {
        const assignFn = functions.httpsCallable('assignMember');
        await assignFn({ memberId, newHrId, newHeadId: hr?.headId || '' });
        Toast.show('تم التعيين', 'success');
      } catch(e) { Toast.show('فشل: ' + e.message, 'error'); }
    },
    async bulkTransfer() {
      const fromId = document.getElementById('bulk-from')?.value;
      const toId = document.getElementById('bulk-to')?.value;
      if (!fromId || !toId) { Toast.show('اختر الـ HR من وإلى', 'error'); return; }
      if (fromId === toId) { Toast.show('الـ HR المصدر والهدف متطابقان', 'error'); return; }
      const ok = await Modal.open('نقل جماعي', `<p style="color:var(--dim)">سيتم نقل جميع أعضاء الـ HR المحدد إلى الآخر.</p>`, 'نقل', true);
      if (!ok) return;
      try {
        const bulk = functions.httpsCallable('bulkAssign');
        await bulk({ fromHrId: fromId, toHrId: toId });
        Toast.show('تم النقل الجماعي', 'success');
        this.load(document.getElementById('pg-assignments'));
      } catch(e) { Toast.show('فشل: ' + e.message, 'error'); }
    }
  },

  /* ─── Cycles ─── */
  'cycles': {
    async load(pg) {
      pg.innerHTML = `<div class="loading-msg"><span class="spin"></span></div>`;
      const cycles = await FS.list('cycles', ['orderBy', 'createdAt', 'desc']);

      pg.innerHTML = `
        <div class="sec-head">
          <h2>🔄 دورات التقييم</h2>
          ${HRAuth.isSuperAdmin() ? '<div class="actions"><button class="btn btn-primary" onclick="Pages[\'cycles\'].createModal()">+ دورة جديدة</button></div>' : ''}
        </div>
        <div style="display:flex;flex-direction:column;gap:12px">
          ${cycles.length === 0 ? '<div class="empty"><span class="ico">🔄</span><p>لا توجد دورات بعد.</p></div>' :
            cycles.map(c => `
            <div class="card">
              <div style="display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:10px">
                <div>
                  <div style="font-weight:700;font-size:1rem">${encStr(c.name)}</div>
                  <div style="color:var(--dim);font-size:.8rem">${c.type || '—'} | ${fmtDate(c.startDate)} ← ${fmtDate(c.endDate)}</div>
                  <div style="color:var(--dim);font-size:.8rem">الموعد النهائي: ${fmtDate(c.deadline)}</div>
                </div>
                <div style="display:flex;align-items:center;gap:8px;flex-wrap:wrap">
                  ${statusBadge(c.status)}
                  ${HRAuth.isSuperAdmin() ? `
                  ${c.status === 'Draft' ? `<button class="btn btn-success btn-sm" onclick="Pages['cycles'].activate('${c.id}')">🚀 تفعيل</button>` : ''}
                  ${c.status === 'Active' ? `<button class="btn btn-warning btn-sm" onclick="Pages['cycles'].editDeadline('${c.id}','${c.name}')">📅 تمديد</button>
                    <button class="btn btn-danger btn-sm" onclick="Pages['cycles'].close('${c.id}')">🔒 إغلاق</button>` : ''}
                  ` : ''}
                </div>
              </div>
              ${c.configSnapshot ? `<div style="margin-top:8px;font-size:.78rem;color:var(--muted)">✅ Snapshot محفوظ ${c.snapshotAt ? '(' + fmtDatetime(c.snapshotAt) + ')' : ''}</div>` : ''}
            </div>`).join('')}
        </div>
      `;
    },
    async createModal() {
      const ok = await Modal.open('+ دورة تقييم جديدة', `
        <div class="form-group"><label>اسم الدورة</label><input id="cy-name" placeholder="مثال: تقييم أكتوبر 2026"></div>
        <div class="form-row cols-2">
          <div class="form-group"><label>النوع</label>
            <select id="cy-type">
              <option value="Monthly">شهرية (Monthly)</option>
              <option value="Biweekly">نصف شهرية (Biweekly)</option>
              <option value="Weekly">أسبوعية (Weekly)</option>
            </select>
          </div>
          <div class="form-group"><label>تاريخ البداية</label><input id="cy-start" type="date"></div>
        </div>
        <div class="form-row cols-2">
          <div class="form-group"><label>تاريخ الانتهاء</label><input id="cy-end" type="date"></div>
          <div class="form-group"><label>الموعد النهائي للتقييم</label><input id="cy-deadline" type="date"></div>
        </div>
        <div style="background:rgba(99,102,241,.08);border-radius:8px;padding:10px;font-size:.8rem;color:var(--dim);margin-top:4px">
          ⚠️ عند الإنشاء، تُحفظ الدورة كـ Draft. عند التفعيل يتم عمل Snapshot كامل للإعدادات الحالية.
        </div>
      `, 'إنشاء الدورة');
      if (!ok) return;
      const name = document.getElementById('cy-name').value.trim();
      const type = document.getElementById('cy-type').value;
      const start = document.getElementById('cy-start').value;
      const end = document.getElementById('cy-end').value;
      const deadline = document.getElementById('cy-deadline').value;
      if (!name || !start || !deadline) { Toast.show('أدخل الاسم والتواريخ', 'error'); return; }
      try {
        await FS.add('cycles', { name, type, startDate: start, endDate: end, deadline: deadline, status: 'Draft', createdBy: HRAuth.uid });
        Toast.show('تم إنشاء الدورة كمسودة', 'success');
        this.load(document.getElementById('pg-cycles'));
      } catch(e) { Toast.show('فشل: ' + e.message, 'error'); }
    },
    async activate(cycleId) {
      const ok = await Modal.open('🚀 تفعيل الدورة', `
        <p style="color:var(--dim)">سيتم عمل <strong>Snapshot</strong> كامل لجميع الإعدادات الحالية (معايير، قواعد، مستويات).</p>
        <p style="color:var(--warning);margin-top:8px;font-size:.85rem">⚠️ لا يمكن التراجع. سيتم إنشاء تقييمات فارغة لكل الأعضاء النشطين.</p>
      `, '🚀 تفعيل', false);
      if (!ok) return;
      try {
        const activate = functions.httpsCallable('activateCycle');
        await activate({ cycleId });
        Toast.show('✅ تم تفعيل الدورة وعمل الـ Snapshot', 'success');
        this.load(document.getElementById('pg-cycles'));
      } catch(e) { Toast.show('فشل التفعيل: ' + e.message, 'error'); }
    },
    async editDeadline(cycleId, name) {
      const ok = await Modal.open(`📅 تمديد موعد "${name}"`, `
        <div class="form-group"><label>الموعد النهائي الجديد</label><input id="cy-new-deadline" type="date"></div>
      `, 'حفظ');
      if (!ok) return;
      const nd = document.getElementById('cy-new-deadline').value;
      if (!nd) { Toast.show('أدخل التاريخ', 'error'); return; }
      try {
        await FS.update('cycles', cycleId, { deadline: nd });
        Toast.show('تم تمديد الموعد', 'success');
        this.load(document.getElementById('pg-cycles'));
      } catch(e) { Toast.show('فشل: ' + e.message, 'error'); }
    },
    async close(cycleId) {
      const ok = await Modal.open('🔒 إغلاق الدورة', `<p style="color:var(--dim)">هل أنت متأكد من إغلاق الدورة؟ لا يمكن للـ HR إرسال تقييمات بعد ذلك.</p>`, 'إغلاق', true);
      if (!ok) return;
      try {
        await FS.update('cycles', cycleId, { status: 'Closed', closedAt: FS.ts() });
        Toast.show('تم إغلاق الدورة', 'success');
        this.load(document.getElementById('pg-cycles'));
      } catch(e) { Toast.show('فشل: ' + e.message, 'error'); }
    }
  },

  /* ─── Evaluations List (Admin) ─── */
  'evaluations-list': {
    async load(pg) {
      pg.innerHTML = `<div class="loading-msg"><span class="spin"></span></div>`;
      const cycles = await FS.list('cycles', ['orderBy', 'createdAt', 'desc']);
      const cycleOpts = cycles.map(c => `<option value="${c.id}">${encStr(c.name)}</option>`).join('');

      pg.innerHTML = `
        <div class="sec-head"><h2>📝 التقييمات</h2></div>
        <div class="filters" style="margin-bottom:16px">
          <select id="ev-cycle" onchange="Pages['evaluations-list'].loadEvals()"><option value="">— كل الدورات —</option>${cycleOpts}</select>
          <select id="ev-status" onchange="Pages['evaluations-list'].loadEvals()">
            <option value="">— كل الحالات —</option>
            <option value="not_started">لم يبدأ</option>
            <option value="draft">مسودة</option>
            <option value="submitted">مُرسل</option>
            <option value="reopened">مُعاد فتحه</option>
          </select>
          <input id="ev-search" placeholder="بحث بالاسم..." oninput="Pages['evaluations-list'].filterTable()" style="max-width:180px">
        </div>
        <div id="evals-container"><div class="empty"><span class="ico">👆</span><p>اختر دورة من الفلتر أعلاه</p></div></div>
      `;
    },
    async loadEvals() {
      const cycleId = document.getElementById('ev-cycle')?.value;
      const status = document.getElementById('ev-status')?.value;
      const container = document.getElementById('evals-container');
      container.innerHTML = `<div class="loading-msg"><span class="spin"></span></div>`;

      let constraints = [];
      if (HRAuth.role === 'head') constraints.push(['where', 'headId', '==', HRAuth.uid]);
      if (cycleId) constraints.push(['where', 'cycleId', '==', cycleId]);
      if (status) constraints.push(['where', 'status', '==', status]);

      const evals = await FS.list('evaluations', ...constraints);

      container.innerHTML = `
        <div class="card tbl-wrap">
          <table id="evals-table">
            <thead><tr><th>العضو</th><th>اللجنة</th><th>الـ HR</th><th>الدرجة</th><th>المستوى</th><th>الحالة</th><th>التاريخ</th><th>إجراء</th></tr></thead>
            <tbody id="evals-tbody">
              ${evals.length === 0 ? '<tr><td colspan="8" style="text-align:center;color:var(--muted);padding:24px">لا توجد تقييمات</td></tr>' :
                evals.map(e => `<tr data-name="${(e.memberName||'').toLowerCase()}">
                  <td><strong>${encStr(e.memberName || e.memberId)}</strong></td>
                  <td>${encStr(e.committee || '—')}</td>
                  <td style="font-size:.8rem;color:var(--muted)">${encStr(e.hrId || '—')}</td>
                  <td style="font-weight:700;color:var(--primary)">${e.finalScore != null ? e.finalScore.toFixed(1) : '—'}</td>
                  <td>${e.levelName ? `<span class="badge badge-primary">${encStr(e.levelName)}</span>` : '—'}</td>
                  <td>${statusBadge(e.status)}</td>
                  <td style="font-size:.8rem">${fmtDate(e.submittedAt)}</td>
                  <td>
                    ${e.status === 'submitted' && (HRAuth.isHead()) ? `
                    <button class="btn btn-warning btn-xs" onclick="Pages['evaluations-list'].reopenModal('${e.id}')">🔓 إعادة فتح</button>` : ''}
                  </td>
                </tr>`).join('')}
            </tbody>
          </table>
        </div>
      `;
    },
    filterTable() {
      const q = document.getElementById('ev-search')?.value.toLowerCase() || '';
      document.querySelectorAll('#evals-tbody tr').forEach(tr => {
        tr.style.display = !q || tr.dataset.name?.includes(q) ? '' : 'none';
      });
    },
    async reopenModal(evalId) {
      const reason = await Modal.prompt('🔓 إعادة فتح التقييم', 'سبب إعادة الفتح...', 'إعادة فتح');
      if (!reason) return;
      try {
        const reopen = functions.httpsCallable('reopenEvaluation');
        await reopen({ evaluationId: evalId, reason });
        Toast.show('تم إعادة فتح التقييم', 'success');
        this.loadEvals();
      } catch(e) { Toast.show('فشل: ' + e.message, 'error'); }
    }
  },

  /* ─── Reopen Requests ─── */
  'reopen-requests': {
    async load(pg) {
      pg.innerHTML = `<div class="loading-msg"><span class="spin"></span></div>`;
      const requests = await FS.list('reopenRequests', ['where', 'status', '==', 'pending'], ['orderBy', 'createdAt', 'desc']);

      pg.innerHTML = `
        <div class="sec-head"><h2>🔓 طلبات إعادة الفتح</h2></div>
        ${requests.length === 0 ? '<div class="empty"><span class="ico">✅</span><p>لا توجد طلبات معلقة</p></div>' : `
        <div style="display:flex;flex-direction:column;gap:12px">
          ${requests.map(r => `
          <div class="card">
            <div style="display:flex;justify-content:space-between;align-items:flex-start;flex-wrap:wrap;gap:10px">
              <div>
                <div style="font-weight:700">${encStr(r.evaluationId)}</div>
                <div style="color:var(--dim);font-size:.85rem;margin-top:4px">السبب: ${encStr(r.reason)}</div>
                <div style="color:var(--muted);font-size:.78rem;margin-top:4px">طُلب في: ${fmtDatetime(r.createdAt)}</div>
              </div>
              <div style="display:flex;gap:8px">
                <button class="btn btn-success btn-sm" onclick="Pages['reopen-requests'].decide('${r.id}','approved')">✅ قبول</button>
                <button class="btn btn-danger btn-sm" onclick="Pages['reopen-requests'].decide('${r.id}','rejected')">❌ رفض</button>
              </div>
            </div>
          </div>`).join('')}
        </div>`}
      `;
    },
    async decide(reqId, decision) {
      try {
        const decide = functions.httpsCallable('decideReopenRequest');
        await decide({ requestId: reqId, decision });
        Toast.show(decision === 'approved' ? 'تمت الموافقة' : 'تم الرفض', 'success');
        this.load(document.getElementById('pg-reopen-requests'));
      } catch(e) { Toast.show('فشل: ' + e.message, 'error'); }
    }
  },

  /* ─── Criteria Management ─── */
  'criteria': {
    async load(pg) {
      pg.innerHTML = `<div class="loading-msg"><span class="spin"></span></div>`;
      const criteria = await FS.list('criteria', ['orderBy', 'order']);

      pg.innerHTML = `
        <div class="sec-head">
          <h2>📐 معايير التقييم</h2>
          <div class="actions">
            <button class="btn btn-primary" onclick="Pages['criteria'].addModal()">+ إضافة معيار</button>
          </div>
        </div>
        <div class="card tbl-wrap">
          <table>
            <thead><tr><th>الاسم</th><th>النوع</th><th>الدرجة القصوى</th><th>الترتيب</th><th>الحالة</th><th>إجراء</th></tr></thead>
            <tbody>
              ${criteria.map(c => `<tr>
                <td><strong>${encStr(c.name)}</strong><div style="font-size:.75rem;color:var(--muted)">${encStr(c.description || '')}</div></td>
                <td><span class="badge ${c.mode === 'rating' ? 'badge-primary' : 'badge-info'}">${c.mode === 'rating' ? 'تقدير (1-5)' : 'درجة مباشرة'}</span></td>
                <td>${c.maxScore}</td>
                <td>${c.order || '—'}</td>
                <td>${c.active !== false ? '<span class="badge badge-success">نشط</span>' : '<span class="badge badge-muted">معطّل</span>'}</td>
                <td>
                  <div style="display:flex;gap:4px">
                    <button class="btn btn-ghost btn-xs" onclick="Pages['criteria'].editModal('${c.id}')">✏️</button>
                    <button class="btn btn-${c.active!==false?'warning':'success'} btn-xs" onclick="Pages['criteria'].toggle('${c.id}',${c.active!==false})">${c.active!==false?'تعطيل':'تفعيل'}</button>
                  </div>
                </td>
              </tr>`).join('')}
            </tbody>
          </table>
        </div>
      `;
      this._criteria = criteria;
    },
    _criteria: [],
    _modalHtml(c = {}) {
      return `
        <div class="form-group"><label>اسم المعيار</label><input id="cr-name" value="${encStr(c.name || '')}" placeholder="مثال: الحضور والانتظام"></div>
        <div class="form-group"><label>الوصف (اختياري)</label><textarea id="cr-desc">${encStr(c.description || '')}</textarea></div>
        <div class="form-row cols-2">
          <div class="form-group"><label>النوع</label>
            <select id="cr-mode" onchange="Pages['criteria']._toggleModeUI()">
              <option value="rating" ${c.mode !== 'direct' ? 'selected' : ''}>تقدير 1-5 مع Mapping</option>
              <option value="direct" ${c.mode === 'direct' ? 'selected' : ''}>درجة مباشرة</option>
            </select>
          </div>
          <div class="form-group"><label>الدرجة القصوى</label><input id="cr-max" type="number" min="1" max="100" value="${c.maxScore || 10}"></div>
        </div>
        <div class="form-group"><label>الترتيب</label><input id="cr-order" type="number" min="1" value="${c.order || 1}"></div>
        <!-- Rating Map (only for rating mode) -->
        <div id="cr-rating-section" style="display:${c.mode !== 'direct' ? 'block' : 'none'}">
          <div style="font-weight:600;margin-bottom:8px;font-size:.85rem;color:var(--dim)">Mapping (نقاط لكل تقدير)</div>
          <div style="display:grid;grid-template-columns:repeat(5,1fr);gap:8px">
            ${[1,2,3,4,5].map(v => `
            <div class="form-group">
              <label>${v} ⭐</label>
              <input id="cr-map-${v}" type="number" min="0" max="100" step="0.5" value="${c.ratingMap?.[v] ?? Math.round(c.maxScore * v / 5) || v*2}">
            </div>`).join('')}
          </div>
          <div style="font-weight:600;margin-bottom:8px;margin-top:12px;font-size:.85rem;color:var(--dim)">ملاحظة تلقائية لكل تقدير</div>
          ${[1,2,3,4,5].map(v => `
          <div class="form-group"><label>${v} ⭐</label><input id="cr-note-${v}" value="${encStr(c.ratingNotes?.[v] || '')}" placeholder="ملاحظة تلقائية للتقدير ${v}"></div>`).join('')}
        </div>
        <div id="cr-direct-section" style="display:${c.mode === 'direct' ? 'block' : 'none'}">
          <div style="color:var(--dim);font-size:.82rem">الـ HR سيدخل رقمًا من 0 إلى الدرجة القصوى مباشرةً.</div>
        </div>
      `;
    },
    _toggleModeUI() {
      const mode = document.getElementById('cr-mode')?.value;
      document.getElementById('cr-rating-section').style.display = mode === 'rating' ? 'block' : 'none';
      document.getElementById('cr-direct-section').style.display = mode === 'direct' ? 'block' : 'none';
    },
    async addModal() {
      const ok = await Modal.open('+ إضافة معيار', this._modalHtml(), 'إضافة', false, true);
      if (!ok) return;
      const data = this._readForm();
      if (!data.name) { Toast.show('أدخل اسم المعيار', 'error'); return; }
      try {
        await FS.add('criteria', { ...data, active: true });
        Toast.show('تم إضافة المعيار', 'success');
        this.load(document.getElementById('pg-criteria'));
      } catch(e) { Toast.show('فشل: ' + e.message, 'error'); }
    },
    async editModal(cId) {
      const c = this._criteria.find(x => x.id === cId);
      if (!c) return;
      const ok = await Modal.open('✏️ تعديل المعيار', this._modalHtml(c), 'حفظ', false, true);
      if (!ok) return;
      const data = this._readForm();
      try {
        await FS.update('criteria', cId, data);
        Toast.show('تم التعديل', 'success');
        this.load(document.getElementById('pg-criteria'));
      } catch(e) { Toast.show('فشل: ' + e.message, 'error'); }
    },
    _readForm() {
      const mode = document.getElementById('cr-mode')?.value || 'rating';
      const maxScore = parseFloat(document.getElementById('cr-max')?.value) || 10;
      const ratingMap = {};
      const ratingNotes = {};
      if (mode === 'rating') {
        [1,2,3,4,5].forEach(v => {
          ratingMap[v] = parseFloat(document.getElementById(`cr-map-${v}`)?.value) || 0;
          ratingNotes[v] = document.getElementById(`cr-note-${v}`)?.value?.trim() || '';
        });
      }
      return {
        name: document.getElementById('cr-name')?.value?.trim() || '',
        description: document.getElementById('cr-desc')?.value?.trim() || '',
        mode, maxScore,
        ratingMap: mode === 'rating' ? ratingMap : null,
        ratingNotes: mode === 'rating' ? ratingNotes : null,
        order: parseInt(document.getElementById('cr-order')?.value) || 1,
      };
    },
    async toggle(cId, isActive) {
      await FS.update('criteria', cId, { active: !isActive });
      Toast.show(isActive ? 'تم التعطيل' : 'تم التفعيل', 'success');
      this.load(document.getElementById('pg-criteria'));
    }
  },

  /* ─── Bonus Rules ─── */
  'bonus-rules': {
    async load(pg) {
      await Pages['bonus-rules']._loadRules(pg, 'bonusRules', '⭐ قواعد المكافآت', 'bonus');
    },
    async _loadRules(pg, col, title, type) {
      const rules = await FS.list(col, ['orderBy', 'createdAt', 'desc']);
      pg.innerHTML = `
        <div class="sec-head">
          <h2>${title}</h2>
          <div class="actions"><button class="btn btn-primary" onclick="Pages['${type === 'bonus' ? 'bonus-rules' : 'penalty-rules'}'].addModal()">+ إضافة قاعدة</button></div>
        </div>
        <div class="card tbl-wrap">
          <table>
            <thead><tr><th>الاسم</th><th>النقاط</th><th>قابلة للتكرار</th><th>الحد الأقصى للتكرار</th><th>الحالة</th><th>إجراء</th></tr></thead>
            <tbody>
              ${rules.length === 0 ? '<tr><td colspan="6" style="text-align:center;color:var(--muted);padding:20px">لا توجد قواعد</td></tr>' :
                rules.map(r => `<tr>
                  <td><strong>${encStr(r.name)}</strong></td>
                  <td style="font-weight:700;color:${type === 'bonus' ? 'var(--success)' : 'var(--danger)'}">
                    ${type === 'bonus' ? '+' : '-'}${r.points}
                  </td>
                  <td>${r.allowMultiple ? '✅' : '—'}</td>
                  <td>${r.maxTimes || '—'}</td>
                  <td>${r.active !== false ? '<span class="badge badge-success">نشطة</span>' : '<span class="badge badge-muted">معطّلة</span>'}</td>
                  <td>
                    <div style="display:flex;gap:4px">
                      <button class="btn btn-ghost btn-xs" onclick="Pages['${type === 'bonus' ? 'bonus-rules' : 'penalty-rules'}'].editModal('${r.id}')">✏️</button>
                      <button class="btn btn-${r.active!==false?'warning':'success'} btn-xs" onclick="Pages['${type === 'bonus' ? 'bonus-rules' : 'penalty-rules'}'].toggle('${r.id}',${r.active!==false},'${col}')">${r.active!==false?'تعطيل':'تفعيل'}</button>
                    </div>
                  </td>
                </tr>`).join('')}
            </tbody>
          </table>
        </div>
      `;
      this._rules = rules;
      this._col = col;
    },
    _rules: [],
    _col: 'bonusRules',
    _ruleModalHtml(r = {}, type = 'bonus') {
      return `
        <div class="form-group"><label>اسم القاعدة</label><input id="rl-name" value="${encStr(r.name || '')}" placeholder="مثال: إنجاز مميز"></div>
        <div class="form-group"><label>النقاط (${type === 'bonus' ? 'موجبة' : 'موجبة — ستُخصم تلقائيًا'})</label>
          <input id="rl-points" type="number" min="0.5" step="0.5" value="${r.points || 5}"></div>
        <div style="display:flex;align-items:center;gap:10px;margin-bottom:12px">
          <input type="checkbox" id="rl-multi" ${r.allowMultiple ? 'checked' : ''} style="width:18px;height:18px">
          <label for="rl-multi" style="cursor:pointer">قابلة للتطبيق أكثر من مرة</label>
        </div>
        <div class="form-group" id="rl-max-wrap" style="display:${r.allowMultiple ? 'flex' : 'none'}">
          <label>الحد الأقصى للتكرار</label>
          <input id="rl-max-times" type="number" min="1" value="${r.maxTimes || 3}">
        </div>
        <script>document.getElementById('rl-multi').addEventListener('change', e => document.getElementById('rl-max-wrap').style.display = e.target.checked ? 'flex' : 'none');<\/script>
      `;
    },
    async addModal() {
      const ok = await Modal.open('+ إضافة قاعدة مكافأة', this._ruleModalHtml({}, 'bonus'), 'إضافة');
      if (!ok) return;
      const data = this._readForm();
      if (!data.name) { Toast.show('أدخل الاسم', 'error'); return; }
      await FS.add('bonusRules', { ...data, active: true });
      Toast.show('تمت الإضافة', 'success');
      this.load(document.getElementById('pg-bonus-rules'));
    },
    async editModal(rId) {
      const r = this._rules.find(x => x.id === rId);
      const ok = await Modal.open('✏️ تعديل القاعدة', this._ruleModalHtml(r, 'bonus'), 'حفظ');
      if (!ok) return;
      await FS.update('bonusRules', rId, this._readForm());
      Toast.show('تم التعديل', 'success');
      this.load(document.getElementById('pg-bonus-rules'));
    },
    _readForm() {
      const allowMultiple = document.getElementById('rl-multi')?.checked || false;
      return {
        name: document.getElementById('rl-name')?.value?.trim() || '',
        points: parseFloat(document.getElementById('rl-points')?.value) || 5,
        allowMultiple,
        maxTimes: allowMultiple ? parseInt(document.getElementById('rl-max-times')?.value) || 3 : null,
      };
    },
    async toggle(rId, isActive, col) {
      await FS.update(col, rId, { active: !isActive });
      Toast.show(isActive ? 'تعطيل' : 'تفعيل', 'success');
      col === 'bonusRules'
        ? this.load(document.getElementById('pg-bonus-rules'))
        : Pages['penalty-rules'].load(document.getElementById('pg-penalty-rules'));
    }
  },

  /* ─── Penalty Rules ─── */
  'penalty-rules': {
    async load(pg) {
      const rules = await FS.list('penaltyRules', ['orderBy', 'createdAt', 'desc']);
      pg.innerHTML = `
        <div class="sec-head">
          <h2>⚠️ قواعد الخصومات</h2>
          <div class="actions"><button class="btn btn-primary" onclick="Pages['penalty-rules'].addModal()">+ إضافة قاعدة</button></div>
        </div>
        <div class="card tbl-wrap">
          <table>
            <thead><tr><th>الاسم</th><th>النقاط المخصومة</th><th>قابلة للتكرار</th><th>الحالة</th><th>إجراء</th></tr></thead>
            <tbody>
              ${rules.length === 0 ? '<tr><td colspan="5" style="text-align:center;color:var(--muted);padding:20px">لا توجد قواعد</td></tr>' :
                rules.map(r => `<tr>
                  <td><strong>${encStr(r.name)}</strong></td>
                  <td style="font-weight:700;color:var(--danger)">-${r.points}</td>
                  <td>${r.allowMultiple ? `✅ (max: ${r.maxTimes || '∞'})` : '—'}</td>
                  <td>${r.active !== false ? '<span class="badge badge-success">نشطة</span>' : '<span class="badge badge-muted">معطّلة</span>'}</td>
                  <td>
                    <div style="display:flex;gap:4px">
                      <button class="btn btn-ghost btn-xs" onclick="Pages['penalty-rules'].editModal('${r.id}')">✏️</button>
                      <button class="btn btn-${r.active!==false?'warning':'success'} btn-xs" onclick="Pages['bonus-rules'].toggle('${r.id}',${r.active!==false},'penaltyRules')">${r.active!==false?'تعطيل':'تفعيل'}</button>
                    </div>
                  </td>
                </tr>`).join('')}
            </tbody>
          </table>
        </div>
      `;
      this._rules = rules;
    },
    _rules: [],
    async addModal() {
      const ok = await Modal.open('+ إضافة قاعدة خصم', Pages['bonus-rules']._ruleModalHtml({}, 'penalty'), 'إضافة');
      if (!ok) return;
      const data = Pages['bonus-rules']._readForm();
      if (!data.name) { Toast.show('أدخل الاسم', 'error'); return; }
      await FS.add('penaltyRules', { ...data, active: true });
      Toast.show('تمت الإضافة', 'success');
      this.load(document.getElementById('pg-penalty-rules'));
    },
    async editModal(rId) {
      const r = this._rules.find(x => x.id === rId);
      const ok = await Modal.open('✏️ تعديل القاعدة', Pages['bonus-rules']._ruleModalHtml(r, 'penalty'), 'حفظ');
      if (!ok) return;
      await FS.update('penaltyRules', rId, Pages['bonus-rules']._readForm());
      Toast.show('تم التعديل', 'success');
      this.load(document.getElementById('pg-penalty-rules'));
    }
  },

  /* ─── Performance Levels ─── */
  'perf-levels': {
    async load(pg) {
      const snap = await db.collection('settings').doc('performanceLevels').get();
      const levels = (snap.exists ? snap.data().levels : []) || [];
      const defaults = [
        { name: 'Outstanding', minScore: 95, finalNote: 'أداء استثنائي!', color: '#10b981' },
        { name: 'Excellent',   minScore: 85, finalNote: 'أداء ممتاز',    color: '#6366f1' },
        { name: 'Very Good',   minScore: 75, finalNote: 'أداء جيد جداً', color: '#38bdf8' },
        { name: 'Good',        minScore: 65, finalNote: 'أداء جيد',      color: '#f59e0b' },
        { name: 'Needs Improvement', minScore: 50, finalNote: 'يحتاج تحسين', color: '#f97316' },
        { name: 'Critical',    minScore: 0,  finalNote: 'ضعيف جداً',    color: '#ef4444' },
      ];
      const display = levels.length > 0 ? levels : defaults;

      pg.innerHTML = `
        <div class="sec-head">
          <h2>🏅 مستويات الأداء</h2>
          <div class="actions">
            <button class="btn btn-primary" onclick="Pages['perf-levels'].saveAll()">💾 حفظ التعديلات</button>
            <button class="btn btn-ghost btn-sm" onclick="Pages['perf-levels'].addLevel()">+ مستوى جديد</button>
          </div>
        </div>
        <div class="card">
          <p style="color:var(--dim);font-size:.82rem;margin-bottom:16px">المستوى = أعلى مستوى تكون درجته ≥ الحد الأدنى (minScore). الترتيب تلقائي من الأعلى للأدنى.</p>
          <div id="levels-list">
            ${display.map((l, i) => this._levelRow(l, i)).join('')}
          </div>
        </div>
      `;
      this._levels = [...display];
    },
    _levels: [],
    _levelRow(l, i) {
      return `
      <div class="item-row" style="margin-bottom:8px" id="level-row-${i}">
        <div style="width:24px;height:24px;border-radius:50%;background:${l.color || '#6366f1'};flex-shrink:0"></div>
        <div style="flex:1;display:grid;grid-template-columns:1fr 100px 1fr 80px;gap:8px;align-items:center">
          <input value="${encStr(l.name)}" placeholder="اسم المستوى" onchange="Pages['perf-levels']._levels[${i}].name=this.value" style="background:var(--surface2);border:1px solid var(--border);border-radius:6px;padding:6px 10px;color:var(--text)">
          <input type="number" value="${l.minScore}" min="0" max="200" placeholder="minScore" onchange="Pages['perf-levels']._levels[${i}].minScore=parseFloat(this.value)||0" style="background:var(--surface2);border:1px solid var(--border);border-radius:6px;padding:6px 10px;color:var(--text);text-align:center">
          <input value="${encStr(l.finalNote || '')}" placeholder="ملاحظة نهائية" onchange="Pages['perf-levels']._levels[${i}].finalNote=this.value" style="background:var(--surface2);border:1px solid var(--border);border-radius:6px;padding:6px 10px;color:var(--text)">
          <input type="color" value="${l.color || '#6366f1'}" onchange="Pages['perf-levels']._levels[${i}].color=this.value;this.previousElementSibling?.previousElementSibling?.previousElementSibling?.previousElementSibling?.style&&(document.getElementById('level-row-${i}').querySelector('[style*=border-radius]').style.background=this.value)" style="width:100%;height:36px;border:none;border-radius:6px;cursor:pointer;background:transparent">
        </div>
        <button class="btn btn-danger btn-xs" onclick="Pages['perf-levels'].removeLevel(${i})">✕</button>
      </div>`;
    },
    addLevel() {
      this._levels.push({ name: 'مستوى جديد', minScore: 0, finalNote: '', color: '#6366f1' });
      const list = document.getElementById('levels-list');
      const i = this._levels.length - 1;
      list.insertAdjacentHTML('beforeend', this._levelRow(this._levels[i], i));
    },
    removeLevel(i) {
      this._levels.splice(i, 1);
      this.load(document.getElementById('pg-perf-levels'));
    },
    async saveAll() {
      const sorted = [...this._levels].sort((a, b) => b.minScore - a.minScore);
      await db.collection('settings').doc('performanceLevels').set({ levels: sorted });
      Toast.show('تم حفظ المستويات', 'success');
    }
  },

  /* ─── Analytics ─── */
  'analytics': {
    async load(pg) {
      pg.innerHTML = `
        <div class="sec-head"><h2>📈 الإحصائيات والتحليل</h2></div>
        <div class="filters">
          <select id="an-cycle" onchange="Pages['analytics'].loadData()">
            <option value="">— كل الدورات —</option>
          </select>
          <select id="an-committee" onchange="Pages['analytics'].loadData()">
            <option value="">— كل اللجان —</option>
          </select>
          <select id="an-hr" onchange="Pages['analytics'].loadData()">
            <option value="">— كل الـ HR —</option>
          </select>
          <input id="an-from" type="date" placeholder="من" onchange="Pages['analytics'].loadData()" title="من تاريخ">
          <input id="an-to"   type="date" placeholder="إلى" onchange="Pages['analytics'].loadData()" title="إلى تاريخ">
        </div>
        <div id="analytics-content"><div class="loading-msg"><span class="spin"></span></div></div>
      `;
      // Load filter options
      const [cycles, hrs] = await Promise.all([
        FS.list('cycles', ['orderBy', 'createdAt', 'desc']),
        FS.list('users', ['where', 'role', '==', 'hr'])
      ]);
      const cycleEl = document.getElementById('an-cycle');
      cycles.forEach(c => { const o = document.createElement('option'); o.value = c.id; o.textContent = c.name; cycleEl.appendChild(o); });
      const hrEl = document.getElementById('an-hr');
      hrs.forEach(h => { const o = document.createElement('option'); o.value = h.id; o.textContent = h.name; hrEl.appendChild(o); });
      await this.loadData();
    },
    async loadData() {
      const container = document.getElementById('analytics-content');
      if (!container) return;
      container.innerHTML = `<div class="loading-msg"><span class="spin"></span></div>`;

      const cycleId = document.getElementById('an-cycle')?.value;
      const hrId = document.getElementById('an-hr')?.value;
      const from = document.getElementById('an-from')?.value;
      const to = document.getElementById('an-to')?.value;

      let constraints = [['where', 'status', '==', 'submitted']];
      if (HRAuth.role === 'head') constraints.push(['where', 'headId', '==', HRAuth.uid]);
      if (cycleId) constraints.push(['where', 'cycleId', '==', cycleId]);
      if (hrId) constraints.push(['where', 'hrId', '==', hrId]);

      const evals = await FS.list('evaluations', ...constraints);

      // Filter by date range
      const filtered = evals.filter(e => {
        if (!e.submittedAt) return false;
        const d = e.submittedAt.toDate ? e.submittedAt.toDate() : new Date(e.submittedAt);
        if (from && d < new Date(from)) return false;
        if (to && d > new Date(to + 'T23:59:59')) return false;
        return true;
      });

      if (filtered.length === 0) {
        container.innerHTML = '<div class="empty"><span class="ico">📊</span><p>لا توجد تقييمات مطابقة للفلتر المحدد.</p></div>';
        return;
      }

      const avg = filtered.reduce((s, e) => s + (e.finalScore || 0), 0) / filtered.length;

      // By committee
      const byCommittee = {};
      filtered.forEach(e => {
        const c = e.committee || 'غير محدد';
        if (!byCommittee[c]) byCommittee[c] = [];
        byCommittee[c].push(e.finalScore || 0);
      });
      const committeeAvgs = Object.entries(byCommittee).map(([name, scores]) => ({
        name, avg: scores.reduce((s,v) => s+v, 0) / scores.length, count: scores.length
      })).sort((a, b) => b.avg - a.avg);

      // By HR
      const byHR = {};
      filtered.forEach(e => {
        if (!byHR[e.hrId]) byHR[e.hrId] = { scores: [], hrName: e.hrId };
        byHR[e.hrId].scores.push(e.finalScore || 0);
      });
      const hrAvgs = Object.values(byHR).map(h => ({
        name: h.hrName, avg: h.scores.reduce((s,v) => s+v, 0) / h.scores.length, count: h.scores.length
      })).sort((a, b) => b.avg - a.avg);

      // Level distribution
      const byLevel = {};
      filtered.forEach(e => {
        const l = e.levelName || 'غير محدد';
        byLevel[l] = (byLevel[l] || 0) + 1;
      });
      const maxBar = Math.max(...committeeAvgs.map(c => c.avg), 1);
      const maxHRBar = Math.max(...hrAvgs.map(h => h.avg), 1);

      container.innerHTML = `
        <div class="grid grid-3" style="margin-bottom:20px">
          <div class="stat-card blue">
            <span class="stat-ico">📊</span>
            <span class="stat-lbl">متوسط الدرجات</span>
            <span class="stat-val">${avg.toFixed(1)}</span>
            <span class="stat-sub">من ${filtered.length} تقييم مُرسل</span>
          </div>
          <div class="stat-card green">
            <span class="stat-ico">🏆</span>
            <span class="stat-lbl">أعلى درجة</span>
            <span class="stat-val">${Math.max(...filtered.map(e => e.finalScore || 0)).toFixed(1)}</span>
          </div>
          <div class="stat-card orange">
            <span class="stat-ico">📉</span>
            <span class="stat-lbl">أدنى درجة</span>
            <span class="stat-val">${Math.min(...filtered.map(e => e.finalScore || 0)).toFixed(1)}</span>
          </div>
        </div>

        <div class="grid grid-2" style="margin-bottom:20px">
          <div class="card">
            <div style="font-weight:700;margin-bottom:14px">📊 متوسط اللجان</div>
            ${committeeAvgs.map(c => `
            <div class="chart-bar">
              <div class="chart-bar-label">${encStr(c.name)}</div>
              <div class="chart-bar-track"><div class="chart-bar-fill" style="width:${Math.round(c.avg/maxBar*100)}%"></div></div>
              <div class="chart-bar-val">${c.avg.toFixed(1)}</div>
            </div>`).join('')}
          </div>
          <div class="card">
            <div style="font-weight:700;margin-bottom:14px">🧑‍💼 متوسط الـ HR</div>
            ${hrAvgs.map(h => `
            <div class="chart-bar">
              <div class="chart-bar-label" style="font-size:.75rem">${encStr(h.name)}</div>
              <div class="chart-bar-track"><div class="chart-bar-fill" style="width:${Math.round(h.avg/maxHRBar*100)}%;background:linear-gradient(90deg,var(--success),#34d399)"></div></div>
              <div class="chart-bar-val">${h.avg.toFixed(1)}</div>
            </div>`).join('')}
          </div>
        </div>

        <div class="card">
          <div style="font-weight:700;margin-bottom:14px">🏅 توزيع المستويات</div>
          <div style="display:flex;gap:10px;flex-wrap:wrap">
            ${Object.entries(byLevel).map(([l, n]) => `
            <div style="background:var(--surface2);border-radius:10px;padding:12px 18px;text-align:center;min-width:100px">
              <div style="font-size:1.4rem;font-weight:900">${n}</div>
              <div style="font-size:.78rem;color:var(--dim)">${encStr(l)}</div>
            </div>`).join('')}
          </div>
        </div>
      `;
    }
  },

  /* ─── Reports ─── */
  'reports': {
    async load(pg) {
      pg.innerHTML = `
        <div class="sec-head"><h2>📑 التقارير</h2></div>
        <div class="card" style="margin-bottom:20px">
          <div style="font-weight:700;margin-bottom:14px">تقرير دورة</div>
          <div class="form-row cols-2">
            <div class="form-group"><label>الدورة</label>
              <select id="rp-cycle"><option value="">— اختر —</option></select>
            </div>
            <div class="form-group"><label>&nbsp;</label>
              <button class="btn btn-primary" onclick="Pages['reports'].generateReport()">🔍 عرض التقرير</button>
            </div>
          </div>
        </div>
        <div id="report-content"></div>
      `;
      const cycles = await FS.list('cycles', ['orderBy', 'createdAt', 'desc']);
      const sel = document.getElementById('rp-cycle');
      cycles.forEach(c => { const o = document.createElement('option'); o.value = c.id; o.textContent = c.name + ' (' + c.status + ')'; sel.appendChild(o); });
    },
    async generateReport() {
      const cycleId = document.getElementById('rp-cycle')?.value;
      if (!cycleId) { Toast.show('اختر الدورة', 'error'); return; }
      const container = document.getElementById('report-content');
      container.innerHTML = `<div class="loading-msg"><span class="spin"></span></div>`;

      let constraints = [['where', 'cycleId', '==', cycleId]];
      if (HRAuth.role === 'head') constraints.push(['where', 'headId', '==', HRAuth.uid]);
      const evals = await FS.list('evaluations', ...constraints);
      const cycle = await FS.get('cycles', cycleId);

      container.innerHTML = `
        <div class="card">
          <div class="sec-head" style="margin-bottom:16px">
            <h2>تقرير: ${encStr(cycle?.name)}</h2>
            <div class="actions">
              <button class="btn btn-ghost btn-sm" onclick="Pages['export'].exportCycle('${cycleId}')">📊 تصدير Sheets</button>
            </div>
          </div>
          <div class="tbl-wrap">
            <table>
              <thead><tr><th>العضو</th><th>اللجنة</th><th>معايير</th><th>مكافآت</th><th>خصومات</th><th>النهائية</th><th>المستوى</th><th>الحالة</th></tr></thead>
              <tbody>
                ${evals.length === 0 ? '<tr><td colspan="8" style="text-align:center;color:var(--muted);padding:20px">لا توجد تقييمات</td></tr>' :
                  evals.map(e => `<tr>
                    <td><strong>${encStr(e.memberName || e.memberId)}</strong></td>
                    <td>${encStr(e.committee || '—')}</td>
                    <td>${e.criteriaTotal?.toFixed(1) || '—'}</td>
                    <td style="color:var(--success)">+${e.bonusTotal || 0}</td>
                    <td style="color:var(--danger)">-${e.penaltyTotal || 0}</td>
                    <td style="font-weight:900;color:var(--primary)">${e.finalScore?.toFixed(1) || '—'}</td>
                    <td>${e.levelName ? `<span class="badge badge-primary">${encStr(e.levelName)}</span>` : '—'}</td>
                    <td>${statusBadge(e.status)}</td>
                  </tr>`).join('')}
              </tbody>
            </table>
          </div>
        </div>
      `;
    }
  },

  /* ─── Export ─── */
  'export': {
    async load(pg) {
      pg.innerHTML = `
        <div class="sec-head"><h2>📊 تصدير إلى Google Sheets</h2></div>
        <div class="card">
          <p style="color:var(--dim);margin-bottom:20px;line-height:1.7">
            يتم إنشاء Spreadsheet في حسابك الشخصي على Google Drive. البيانات تُفلتر Server-side حسب صلاحياتك.
          </p>
          <div class="form-group" style="margin-bottom:16px"><label>الدورة</label>
            <select id="ex-cycle"><option value="">— كل الدورات —</option></select>
          </div>
          <button class="btn btn-primary" id="export-btn" onclick="Pages['export'].startExport()">
            <span style="font-size:1.1rem">G</span> Continue with Google
          </button>
          <div id="export-result" style="margin-top:20px"></div>
        </div>
      `;
      const cycles = await FS.list('cycles', ['orderBy', 'createdAt', 'desc']);
      const sel = document.getElementById('ex-cycle');
      cycles.forEach(c => { const o = document.createElement('option'); o.value = c.id; o.textContent = c.name; sel.appendChild(o); });
    },
    async exportCycle(cycleId) {
      App.setSection('export');
      setTimeout(() => { const sel = document.getElementById('ex-cycle'); if(sel && cycleId) sel.value = cycleId; }, 300);
    },
    async startExport() {
      const cycleId = document.getElementById('ex-cycle')?.value || null;
      const resultEl = document.getElementById('export-result');
      document.getElementById('export-btn').disabled = true;
      resultEl.innerHTML = `<div class="loading-msg"><span class="spin"></span> جاري فتح نافذة Google OAuth...</div>`;

      try {
        // Get OAuth URL from Cloud Function
        const getOAuthUrl = functions.httpsCallable('getGoogleOAuthUrl');
        const { data } = await getOAuthUrl({ cycleId });
        const oauthUrl = data?.url;
        if (!oauthUrl) throw new Error('لم يتم الحصول على رابط OAuth');

        // Open OAuth popup
        const popup = window.open(oauthUrl, 'google_oauth', 'width=500,height=600');

        // Listen for OAuth callback message
        const handler = async (event) => {
          if (event.data?.type !== 'GOOGLE_OAUTH_CODE') return;
          window.removeEventListener('message', handler);
          popup?.close();

          const authCode = event.data.code;
          resultEl.innerHTML = `<div class="loading-msg"><span class="spin"></span> جاري إنشاء الـ Spreadsheet...</div>`;

          const exportFn = functions.httpsCallable('exportToSheets');
          const result = await exportFn({ authCode, cycleId });
          const sheetUrl = result.data?.sheetUrl;

          resultEl.innerHTML = `
            <div style="background:rgba(16,185,129,.1);border:1px solid rgba(16,185,129,.3);border-radius:10px;padding:16px">
              <div style="color:var(--success);font-weight:700;margin-bottom:8px">✅ تم التصدير بنجاح!</div>
              <a href="${encStr(sheetUrl)}" target="_blank" class="btn btn-success">📊 فتح الـ Spreadsheet</a>
            </div>
          `;
        };

        window.addEventListener('message', handler);

        // Fallback timeout
        setTimeout(() => {
          window.removeEventListener('message', handler);
          if (resultEl.innerHTML.includes('spin')) {
            resultEl.innerHTML = `<div style="color:var(--danger)">انتهت مهلة OAuth. حاول مرة أخرى.</div>`;
          }
        }, 120000);

      } catch(e) {
        resultEl.innerHTML = `<div style="color:var(--danger)">❌ فشل: ${encStr(e.message)}</div>`;
      } finally {
        document.getElementById('export-btn').disabled = false;
      }
    }
  },

  /* ─── Audit Log ─── */
  'audit-log': {
    async load(pg) {
      pg.innerHTML = `<div class="loading-msg"><span class="spin"></span></div>`;
      const logs = await FS.list('auditLogs', ['orderBy', 'timestamp', 'desc'], ['limit', 100]);

      pg.innerHTML = `
        <div class="sec-head"><h2>🔍 سجل النشاط</h2><div style="font-size:.8rem;color:var(--muted);margin-right:auto">آخر 100 عملية</div></div>
        <div class="card tbl-wrap">
          <table>
            <thead><tr><th>الوقت</th><th>المستخدم</th><th>الدور</th><th>الإجراء</th><th>الكيان</th></tr></thead>
            <tbody>
              ${logs.length === 0 ? '<tr><td colspan="5" style="text-align:center;color:var(--muted);padding:24px">لا توجد سجلات</td></tr>' :
                logs.map(l => `<tr>
                  <td style="font-size:.78rem;color:var(--muted);white-space:nowrap">${fmtDatetime(l.timestamp)}</td>
                  <td>${encStr(l.actorId || '—')}</td>
                  <td><span class="badge badge-muted">${encStr(l.actorRole || '—')}</span></td>
                  <td style="color:var(--text)">${encStr(l.action || '—')}</td>
                  <td style="font-size:.8rem;color:var(--dim)">${encStr(l.entityType || '')} ${encStr(l.entityId ? '#'+l.entityId.slice(0,8) : '')}</td>
                </tr>`).join('')}
            </tbody>
          </table>
        </div>
      `;
    }
  },

}; // end Pages

/* ═══════════════════════════════════════════════
   Item Row helper style (used in some pages)
═══════════════════════════════════════════════ */
const style = document.createElement('style');
style.textContent = `.item-row{background:var(--surface);border:1px solid var(--border);border-radius:var(--r);padding:13px 16px;display:flex;align-items:center;gap:12px;transition:border-color .15s}`;
document.head.appendChild(style);

/* ═══════════════════════════════════════════════
   Boot
═══════════════════════════════════════════════ */
document.addEventListener('DOMContentLoaded', async () => {
  const ok = initFirebase();
  if (!ok) return;

  // Check if already signed in (persistent session)
  auth.onAuthStateChanged(async user => {
    if (user) {
      const snap = await db.collection('users').doc(user.uid).get();
      if (snap.exists) {
        const d = snap.data();
        HRAuth.currentUser = { uid: user.uid, role: d.role, name: d.name, headId: d.headId };
        document.getElementById('app').classList.add('show');
        App.initAfterAuth();
        return;
      }
    }
    // Show auth screen
    document.getElementById('auth-screen').classList.add('show');
    setTimeout(() => document.getElementById('code-input')?.focus(), 100);
  });
});
