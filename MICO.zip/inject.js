const fs = require('fs');
let html = fs.readFileSync('web/hr.html', 'utf8');

if (!html.includes('deleteItem(collection')) {
  html = html.replace('setSection(s) {', `async deleteItem(collection, id, refreshPage) {
    if(!await Modal.open('تأكيد الحذف', 'هل أنت متأكد من حذف هذا العنصر؟ لا يمكن التراجع.', 'حذف', true)) return;
    try { await FS.del(collection, id); Toast.show('تم الحذف', 'success'); Pages[refreshPage].load(document.getElementById('pg-'+refreshPage)); } 
    catch(e) { Toast.show('خطأ: ' + e.message, 'error'); }
  },
  async deleteAll(collection, refreshPage) {
    if(!await Modal.open('حذف الكل', '⚠️ هل أنت متأكد من حذف <b>جميع</b> العناصر في هذا القسم؟ لا يمكن التراجع أبداً!', 'حذف الكل', true)) return;
    try {
      const all = await FS.list(collection);
      for(const item of all) await FS.del(collection, item.id);
      Toast.show('تم حذف الكل', 'success');
      Pages[refreshPage].load(document.getElementById('pg-'+refreshPage));
    } catch(e) { Toast.show('خطأ: ' + e.message, 'error'); }
  },
  setSection(s) {`);
}

const pages = [
  { name: 'members-mgmt', collection: 'members', 
    itemBtnRegex: /<button class="btn btn-warning btn-xs" onclick="Pages\['members-mgmt'\].toggleActive\('\$\{m\.id\}', \$\{m\.active\}\)">تعطيل<\/button>/g, 
    headRegex: /<div class="actions">\s*<button class="btn btn-primary" onclick="Pages\['members-mgmt'\].addModal\(\)">\+ إضافة عضو<\/button>\s*<\/div>/, 
    itemBtnRepl: '<button class="btn btn-warning btn-xs" onclick="Pages[\'members-mgmt\'].toggleActive(\'${m.id}\', ${m.active})">تعطيل</button><button class="btn btn-danger btn-xs" onclick="App.deleteItem(\'members\', \'${m.id}\', \'members-mgmt\')">🗑️</button>', 
    headRepl: '<div class="actions"><button class="btn btn-danger" onclick="App.deleteAll(\'members\', \'members-mgmt\')">🗑️ حذف الكل</button><button class="btn btn-primary" onclick="Pages[\'members-mgmt\'].addModal()">+ إضافة عضو</button></div>' },
  
  { name: 'hr-mgmt', collection: 'users', 
    itemBtnRegex: /<button class="btn btn-\$\{hr\.active !== false \? 'warning' : 'success'\} btn-xs" onclick="Pages\['hr-mgmt'\].toggleActive\('\$\{hr\.id\}',\$\{hr\.active !== false\}\)">\$\{hr\.active !== false \? 'تعطيل' : 'تفعيل'\}<\/button>/g, 
    headRegex: /<div class="actions"><button class="btn btn-primary" onclick="Pages\['hr-mgmt'\].addModal\(\)">\+ إضافة HR<\/button><\/div>/, 
    itemBtnRepl: '<button class="btn btn-${hr.active !== false ? \'warning\' : \'success\'} btn-xs" onclick="Pages[\'hr-mgmt\'].toggleActive(\'${hr.id}\',${hr.active !== false})">${hr.active !== false ? \'تعطيل\' : \'تفعيل\'}</button><button class="btn btn-danger btn-xs" onclick="App.deleteItem(\'users\', \'${hr.id}\', \'hr-mgmt\')">🗑️</button>', 
    headRepl: '<div class="actions"><button class="btn btn-danger" onclick="App.deleteAll(\'users\', \'hr-mgmt\')">🗑️ حذف الكل</button><button class="btn btn-primary" onclick="Pages[\'hr-mgmt\'].addModal()">+ إضافة HR</button></div>' },

  { name: 'assignments', collection: 'assignments', 
    itemBtnRegex: /<button class="btn btn-ghost btn-xs" onclick="Pages\['assignments'\].load\(document.getElementById\('pg-assignments'\)\)">🔄 تحديث<\/button>/g, 
    headRegex: /<div class="actions">\s*<button class="btn btn-ghost btn-sm" onclick="Pages\['assignments'\].load\(document.getElementById\('pg-assignments'\)\)">🔄 تحديث<\/button>\s*<\/div>/, 
    itemBtnRepl: '', 
    headRepl: '<div class="actions"><button class="btn btn-danger btn-sm" onclick="App.deleteAll(\'assignments\', \'assignments\')">🗑️ حذف الكل</button><button class="btn btn-ghost btn-sm" onclick="Pages[\'assignments\'].load(document.getElementById(\'pg-assignments\'))">🔄 تحديث</button></div>' },

  { name: 'cycles', collection: 'cycles', 
    itemBtnRegex: /<button class="btn btn-ghost btn-xs" onclick="Pages\['cycles'\].editModal\('\$\{c\.id\}'\)">✏️<\/button>/g, 
    headRegex: /<div class="actions"><button class="btn btn-primary" onclick="Pages\['cycles'\].addModal\(\)">\+ دورة جديدة<\/button><\/div>/, 
    itemBtnRepl: '<button class="btn btn-ghost btn-xs" onclick="Pages[\'cycles\'].editModal(\'${c.id}\')">✏️</button><button class="btn btn-danger btn-xs" onclick="App.deleteItem(\'cycles\', \'${c.id}\', \'cycles\')">🗑️</button>', 
    headRepl: '<div class="actions"><button class="btn btn-danger" onclick="App.deleteAll(\'cycles\', \'cycles\')">🗑️ حذف الكل</button><button class="btn btn-primary" onclick="Pages[\'cycles\'].addModal()">+ دورة جديدة</button></div>' },
  
  { name: 'criteria', collection: 'criteria', 
    itemBtnRegex: /<button class="btn btn-ghost btn-xs" onclick="Pages\['criteria'\].editModal\('\$\{c\.id\}'\)">✏️<\/button>/g, 
    headRegex: /<div class="actions"><button class="btn btn-primary" onclick="Pages\['criteria'\].addModal\(\)">\+ معيار جديد<\/button><\/div>/, 
    itemBtnRepl: '<button class="btn btn-ghost btn-xs" onclick="Pages[\'criteria\'].editModal(\'${c.id}\')">✏️</button><button class="btn btn-danger btn-xs" onclick="App.deleteItem(\'criteria\', \'${c.id}\', \'criteria\')">🗑️</button>', 
    headRepl: '<div class="actions"><button class="btn btn-danger" onclick="App.deleteAll(\'criteria\', \'criteria\')">🗑️ حذف الكل</button><button class="btn btn-primary" onclick="Pages[\'criteria\'].addModal()">+ معيار جديد</button></div>' },
  
  { name: 'bonus-rules', collection: 'bonusRules', 
    itemBtnRegex: /<button class="btn btn-ghost btn-xs" onclick="Pages\['bonus-rules'\].editModal\('\$\{r\.id\}'\)">✏️<\/button>/g, 
    headRegex: /<div class="actions"><button class="btn btn-primary" onclick="Pages\['bonus-rules'\].addModal\(\)">\+ قاعدة جديدة<\/button><\/div>/, 
    itemBtnRepl: '<button class="btn btn-ghost btn-xs" onclick="Pages[\'bonus-rules\'].editModal(\'${r.id}\')">✏️</button><button class="btn btn-danger btn-xs" onclick="App.deleteItem(\'bonusRules\', \'${r.id}\', \'bonus-rules\')">🗑️</button>', 
    headRepl: '<div class="actions"><button class="btn btn-danger" onclick="App.deleteAll(\'bonusRules\', \'bonus-rules\')">🗑️ حذف الكل</button><button class="btn btn-primary" onclick="Pages[\'bonus-rules\'].addModal()">+ قاعدة جديدة</button></div>' },
  
  { name: 'penalty-rules', collection: 'penaltyRules', 
    itemBtnRegex: /<button class="btn btn-ghost btn-xs" onclick="Pages\['penalty-rules'\].editModal\('\$\{r\.id\}'\)">✏️<\/button>/g, 
    headRegex: /<div class="actions"><button class="btn btn-primary" onclick="Pages\['penalty-rules'\].addModal\(\)">\+ قاعدة جديدة<\/button><\/div>/, 
    itemBtnRepl: '<button class="btn btn-ghost btn-xs" onclick="Pages[\'penalty-rules\'].editModal(\'${r.id}\')">✏️</button><button class="btn btn-danger btn-xs" onclick="App.deleteItem(\'penaltyRules\', \'${r.id}\', \'penalty-rules\')">🗑️</button>', 
    headRepl: '<div class="actions"><button class="btn btn-danger" onclick="App.deleteAll(\'penaltyRules\', \'penalty-rules\')">🗑️ حذف الكل</button><button class="btn btn-primary" onclick="Pages[\'penalty-rules\'].addModal()">+ قاعدة جديدة</button></div>' },
  
  { name: 'perf-levels', collection: 'perfLevels', 
    itemBtnRegex: /<button class="btn btn-ghost btn-xs" onclick="Pages\['perf-levels'\].editModal\('\$\{l\.id\}'\)">✏️<\/button>/g, 
    headRegex: /<div class="actions"><button class="btn btn-primary" onclick="Pages\['perf-levels'\].addModal\(\)">\+ مستوى جديد<\/button><\/div>/, 
    itemBtnRepl: '<button class="btn btn-ghost btn-xs" onclick="Pages[\'perf-levels\'].editModal(\'${l.id}\')">✏️</button><button class="btn btn-danger btn-xs" onclick="App.deleteItem(\'perfLevels\', \'${l.id}\', \'perf-levels\')">🗑️</button>', 
    headRepl: '<div class="actions"><button class="btn btn-danger" onclick="App.deleteAll(\'perfLevels\', \'perf-levels\')">🗑️ حذف الكل</button><button class="btn btn-primary" onclick="Pages[\'perf-levels\'].addModal()">+ مستوى جديد</button></div>' },

  { name: 'evaluations-list', collection: 'evaluations',
    itemBtnRegex: /<button class="btn btn-ghost btn-xs" onclick="Pages\['evaluations-list'\].viewEval\('\$\{e\.id\}'\)">👁️<\/button>/g,
    headRegex: /<div class="actions"><button class="btn btn-ghost btn-sm" onclick="Pages\['evaluations-list'\].load\(document.getElementById\('pg-evaluations-list'\)\)">🔄 تحديث<\/button><\/div>/,
    itemBtnRepl: '<button class="btn btn-ghost btn-xs" onclick="Pages[\'evaluations-list\'].viewEval(\'${e.id}\')">👁️</button><button class="btn btn-danger btn-xs" onclick="App.deleteItem(\'evaluations\', \'${e.id}\', \'evaluations-list\')">🗑️</button>',
    headRepl: '<div class="actions"><button class="btn btn-danger btn-sm" onclick="App.deleteAll(\'evaluations\', \'evaluations-list\')">🗑️ حذف الكل</button><button class="btn btn-ghost btn-sm" onclick="Pages[\'evaluations-list\'].load(document.getElementById(\'pg-evaluations-list\'))">🔄 تحديث</button></div>'
  }
];

for(const p of pages) {
  if (p.itemBtnRegex && p.itemBtnRepl) {
    if(!html.match(p.itemBtnRegex)) console.log('Item Btn not found for', p.name);
    html = html.replace(p.itemBtnRegex, p.itemBtnRepl);
  }
  if (p.headRegex && p.headRepl) {
    if(!html.match(p.headRegex)) console.log('Head not found for', p.name);
    html = html.replace(p.headRegex, p.headRepl);
  }
}

fs.writeFileSync('web/hr.html', html);
console.log('Successfully added delete features.');
