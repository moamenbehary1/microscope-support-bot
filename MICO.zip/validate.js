const fs = require('fs');
const html = fs.readFileSync('web/index.html', 'utf8');
const match = html.match(/<script[^>]*>([\s\S]*?)<\/script>/);
if (match) {
  const js = match[1];
  const vm = require('vm');
  try {
    new vm.Script(js, { filename: 'index.js' });
    console.log("No syntax errors found.");
  } catch (e) {
    console.error("Syntax Error at line:", e.stack);
  }
} else {
  console.log("No script tag found.");
}
