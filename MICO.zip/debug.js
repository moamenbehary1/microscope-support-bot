const url = 'https://dataforbot-bbd6b-default-rtdb.firebaseio.com/';
const secret = 'MSdHnbcYnC5TxucBtdUs7qHhVFd88l1CDOSKLr7g';

async function run() {
  const hrRes = await fetch(`${url}/hr_users.json?auth=${secret}`);
  const hrs = await hrRes.json();
  
  const mRes = await fetch(`${url}/hr_members.json?auth=${secret}`);
  const members = await mRes.json();

  console.log('--- HR Users ---');
  for (let k in hrs) {
    console.log(k, hrs[k].name, hrs[k].role);
  }

  console.log('\n--- Members ---');
  for (let k in members) {
    console.log(k, members[k].name, 'assignedHrId:', members[k].assignedHrId, 'active:', members[k].active);
  }
}

run();
