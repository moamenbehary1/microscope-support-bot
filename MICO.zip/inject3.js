const fs = require('fs');
let html = fs.readFileSync('web/hr.html', 'utf8');

// 1. Fix FS.list to support '!=' constraint
if (!html.includes('c[2] === \'!=\'')) {
  html = html.replace(
    "if (c[2] === 'array-contains') return Array.isArray(item[c[1]]) && item[c[1]].includes(c[3]);\n            return true;",
    "if (c[2] === 'array-contains') return Array.isArray(item[c[1]]) && item[c[1]].includes(c[3]);\n            if (c[2] === '!=') return item[c[1]] !== c[3];\n            return true;"
  );
}

// 2. Change ['where', 'active', '==', true] to ['where', 'active', '!=', false] everywhere
html = html.replace(/\['where', 'active', '==', true\]/g, "['where', 'active', '!=', false]");

// 3. Make sure toggleActive correctly toggles between true and false if undefined
// currently it does: `active: !currentActive`. If currentActive is undefined, !undefined = true. So that works.

fs.writeFileSync('web/hr.html', html);
console.log('Fixed active query issue!');
