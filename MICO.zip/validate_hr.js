const fs = require('fs');
const html = fs.readFileSync('web/hr.html', 'utf8');
const startIndex = html.indexOf("<script>\n'use strict';");
const endIndex = html.lastIndexOf("</script>");
if (startIndex !== -1 && endIndex !== -1) {
  const script = html.substring(startIndex + 8, endIndex);
  const vm = require('vm');
  try {
    new vm.Script(script);
    console.log('Syntax OK');
  } catch(e) {
    console.error('Error:', e.stack);
  }
} else {
  console.log('Script tag not found');
}
