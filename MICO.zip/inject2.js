const fs = require('fs');
let html = fs.readFileSync('web/hr.html', 'utf8');

// 1. Nav Item
const navHRTarget = `<div class="nav-sep hr-only"></div>`;
const navHRRepl = `<div class="nav-item hr-only" data-s="hr-comments"><span class="icon">💬</span><span>التعليقات</span></div>\n      <div class="nav-sep hr-only"></div>`;
if (html.includes(navHRTarget) && !html.includes('data-s="hr-comments"')) {
    html = html.replace(navHRTarget, navHRRepl);
}

// 2. Page Div
const pageTarget = `<!-- Admin/Head Pages -->`;
const pageRepl = `<div id="pg-hr-comments" class="page"></div>\n      <!-- Admin/Head Pages -->`;
if (html.includes(pageTarget) && !html.includes('id="pg-hr-comments"')) {
    html = html.replace(pageTarget, pageRepl);
}

// 3. Title mapping
const titleTarget = `'hr-history': 'سجل التقييمات',`;
const titleRepl = `'hr-history': 'سجل التقييمات',\n      'hr-comments': 'التعليقات المباشرة',`;
if (html.includes(titleTarget) && !html.includes("'hr-comments':")) {
    html = html.replace(titleTarget, titleRepl);
}

// 4. Page Logic
const logicTarget = `/* ─── HR Management ─── */`;
const logicRepl = `/* ─── HR Comments ─── */
  'hr-comments': {
    async load(pg) {
      pg.innerHTML = \`<div class="loading-msg"><span class="spin"></span></div>\`;
      const comments = await FS.list('comments', ['orderBy', 'timestamp', 'desc']);
      
      let html = \`
        <div class="sec-head">
          <h2>💬 التعليقات والملاحظات</h2>
          <div class="actions">
             <button class="btn btn-primary" onclick="Pages['hr-comments'].addModal()">+ إضافة تعليق</button>
             <button class="btn btn-ghost" onclick="Pages['hr-comments'].load(document.getElementById('pg-hr-comments'))">🔄 تحديث</button>
          </div>
        </div>
        <div class="card" style="display:flex;flex-direction:column;gap:12px;">
      \`;
      
      if(comments.length === 0) {
        html += \`<div class="empty"><span class="ico">📭</span><p>لا توجد تعليقات حتى الآن</p></div>\`;
      } else {
        for(const c of comments) {
          html += \`
            <div style="background:var(--surface2);padding:16px;border-radius:12px;border:1px solid var(--border);">
              <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:8px;">
                <div>
                  <strong style="color:var(--primary);font-size:1rem;">\${encStr(c.senderName)}</strong>
                  <span class="badge badge-muted" style="margin-right:8px;">لجنة: \${encStr(c.committee)}</span>
                </div>
                <div style="font-size:0.75rem;color:var(--dim);">\${fmtDatetime(c.timestamp)}</div>
              </div>
              <p style="color:var(--text);line-height:1.6;white-space:pre-wrap;">\${encStr(c.content)}</p>
              \${HRAuth.isSuperAdmin() || HRAuth.uid === c.senderId ? \`<div style="text-align:left;margin-top:8px;"><button class="btn btn-danger btn-xs" onclick="App.deleteItem('comments', '\${c.id}', 'hr-comments')">🗑️ حذف</button></div>\` : ''}
            </div>
          \`;
        }
      }
      
      html += \`</div>\`;
      pg.innerHTML = html;
    },
    async addModal() {
      const ok = await Modal.open('+ إضافة تعليق جديد', \`
        <div class="form-group"><label>اللجنة التي تتبع لها</label><input id="c-committee" placeholder="مثال: PR, IT, Logistics..."></div>
        <div class="form-group"><label>التعليق / الملاحظة</label><textarea id="c-content" placeholder="اكتب تعليقك هنا..." style="height:120px"></textarea></div>
      \`, 'إرسال التعليق');
      if (!ok) return;
      const committee = document.getElementById('c-committee').value.trim();
      const content = document.getElementById('c-content').value.trim();
      if (!content || !committee) { Toast.show('يرجى تعبئة جميع الحقول', 'error'); return; }
      
      try {
        await FS.add('comments', {
          senderId: HRAuth.uid,
          senderName: HRAuth.name,
          committee: committee,
          content: content,
          timestamp: FS.ts()
        });
        Toast.show('تم إضافة التعليق بنجاح', 'success');
        this.load(document.getElementById('pg-hr-comments'));
      } catch(e) { Toast.show('فشل: ' + e.message, 'error'); }
    }
  },

  /* ─── HR Management ─── */`;

if (html.includes(logicTarget) && !html.includes("'hr-comments': {")) {
    html = html.replace(logicTarget, logicRepl);
}

// 5. Hardcode replacements for remaining Delete buttons where possible
// hr-mgmt
html = html.replace(
  '${HRAuth.isSuperAdmin() ? \'<div class="actions"><button class="btn btn-primary" onclick="Pages[\\\'hr-mgmt\\\'].addModal()">+ إضافة HR</button></div>\' : \'\'}',
  '${HRAuth.isSuperAdmin() ? \'<div class="actions"><button class="btn btn-danger" onclick="App.deleteAll(\\\'users\\\', \\\'hr-mgmt\\\')">🗑️ حذف الكل</button><button class="btn btn-primary" onclick="Pages[\\\'hr-mgmt\\\'].addModal()">+ إضافة HR</button></div>\' : \'\'}'
);
html = html.replace(
  '<button class="btn btn-${hr.active !== false ? \'warning\' : \'success\'} btn-xs" onclick="Pages[\'hr-mgmt\'].toggleActive(\'${hr.id}\',${hr.active !== false})">${hr.active !== false ? \'تعطيل\' : \'تفعيل\'}</button>',
  '<button class="btn btn-${hr.active !== false ? \'warning\' : \'success\'} btn-xs" onclick="Pages[\'hr-mgmt\'].toggleActive(\'${hr.id}\',${hr.active !== false})">${hr.active !== false ? \'تعطيل\' : \'تفعيل\'}</button><button class="btn btn-danger btn-xs" onclick="App.deleteItem(\'users\', \'${hr.id}\', \'hr-mgmt\')">🗑️</button>'
);

// cycles
html = html.replace(
  '<div class="actions"><button class="btn btn-primary" onclick="Pages[\'cycles\'].addModal()">+ دورة جديدة</button></div>',
  '<div class="actions"><button class="btn btn-danger" onclick="App.deleteAll(\'cycles\', \'cycles\')">🗑️ حذف الكل</button><button class="btn btn-primary" onclick="Pages[\'cycles\'].addModal()">+ دورة جديدة</button></div>'
);
html = html.replace(
  '<button class="btn btn-ghost btn-xs" onclick="Pages[\'cycles\'].editModal(\'${c.id}\')">✏️</button>',
  '<button class="btn btn-ghost btn-xs" onclick="Pages[\'cycles\'].editModal(\'${c.id}\')">✏️</button><button class="btn btn-danger btn-xs" onclick="App.deleteItem(\'cycles\', \'${c.id}\', \'cycles\')">🗑️</button>'
);

// criteria
html = html.replace(
  '<div class="actions"><button class="btn btn-primary" onclick="Pages[\'criteria\'].addModal()">+ معيار جديد</button></div>',
  '<div class="actions"><button class="btn btn-danger" onclick="App.deleteAll(\'criteria\', \'criteria\')">🗑️ حذف الكل</button><button class="btn btn-primary" onclick="Pages[\'criteria\'].addModal()">+ معيار جديد</button></div>'
);
html = html.replace(
  '<button class="btn btn-ghost btn-xs" onclick="Pages[\'criteria\'].editModal(\'${c.id}\')">✏️</button>',
  '<button class="btn btn-ghost btn-xs" onclick="Pages[\'criteria\'].editModal(\'${c.id}\')">✏️</button><button class="btn btn-danger btn-xs" onclick="App.deleteItem(\'criteria\', \'${c.id}\', \'criteria\')">🗑️</button>'
);

// bonus-rules
html = html.replace(
  '<div class="actions"><button class="btn btn-primary" onclick="Pages[\'bonus-rules\'].addModal()">+ قاعدة جديدة</button></div>',
  '<div class="actions"><button class="btn btn-danger" onclick="App.deleteAll(\'bonusRules\', \'bonus-rules\')">🗑️ حذف الكل</button><button class="btn btn-primary" onclick="Pages[\'bonus-rules\'].addModal()">+ قاعدة جديدة</button></div>'
);
html = html.replace(
  '<button class="btn btn-ghost btn-xs" onclick="Pages[\'bonus-rules\'].editModal(\'${r.id}\')">✏️</button>',
  '<button class="btn btn-ghost btn-xs" onclick="Pages[\'bonus-rules\'].editModal(\'${r.id}\')">✏️</button><button class="btn btn-danger btn-xs" onclick="App.deleteItem(\'bonusRules\', \'${r.id}\', \'bonus-rules\')">🗑️</button>'
);

// penalty-rules
html = html.replace(
  '<div class="actions"><button class="btn btn-primary" onclick="Pages[\'penalty-rules\'].addModal()">+ قاعدة جديدة</button></div>',
  '<div class="actions"><button class="btn btn-danger" onclick="App.deleteAll(\'penaltyRules\', \'penalty-rules\')">🗑️ حذف الكل</button><button class="btn btn-primary" onclick="Pages[\'penalty-rules\'].addModal()">+ قاعدة جديدة</button></div>'
);
html = html.replace(
  '<button class="btn btn-ghost btn-xs" onclick="Pages[\'penalty-rules\'].editModal(\'${r.id}\')">✏️</button>',
  '<button class="btn btn-ghost btn-xs" onclick="Pages[\'penalty-rules\'].editModal(\'${r.id}\')">✏️</button><button class="btn btn-danger btn-xs" onclick="App.deleteItem(\'penaltyRules\', \'${r.id}\', \'penalty-rules\')">🗑️</button>'
);

// perf-levels
html = html.replace(
  '<div class="actions"><button class="btn btn-primary" onclick="Pages[\'perf-levels\'].addModal()">+ مستوى جديد</button></div>',
  '<div class="actions"><button class="btn btn-danger" onclick="App.deleteAll(\'perfLevels\', \'perf-levels\')">🗑️ حذف الكل</button><button class="btn btn-primary" onclick="Pages[\'perf-levels\'].addModal()">+ مستوى جديد</button></div>'
);
html = html.replace(
  '<button class="btn btn-ghost btn-xs" onclick="Pages[\'perf-levels\'].editModal(\'${l.id}\')">✏️</button>',
  '<button class="btn btn-ghost btn-xs" onclick="Pages[\'perf-levels\'].editModal(\'${l.id}\')">✏️</button><button class="btn btn-danger btn-xs" onclick="App.deleteItem(\'perfLevels\', \'${l.id}\', \'perf-levels\')">🗑️</button>'
);

// evaluations-list
html = html.replace(
  '<div class="actions"><button class="btn btn-ghost btn-sm" onclick="Pages[\'evaluations-list\'].load(document.getElementById(\'pg-evaluations-list\'))">🔄 تحديث</button></div>',
  '<div class="actions"><button class="btn btn-danger btn-sm" onclick="App.deleteAll(\'evaluations\', \'evaluations-list\')">🗑️ حذف الكل</button><button class="btn btn-ghost btn-sm" onclick="Pages[\'evaluations-list\'].load(document.getElementById(\'pg-evaluations-list\'))">🔄 تحديث</button></div>'
);
html = html.replace(
  '<button class="btn btn-ghost btn-xs" onclick="Pages[\'evaluations-list\'].viewEval(\'${e.id}\')">👁️</button>',
  '<button class="btn btn-ghost btn-xs" onclick="Pages[\'evaluations-list\'].viewEval(\'${e.id}\')">👁️</button><button class="btn btn-danger btn-xs" onclick="App.deleteItem(\'evaluations\', \'${e.id}\', \'evaluations-list\')">🗑️</button>'
);

fs.writeFileSync('web/hr.html', html);
console.log('Update finished!');
